# Русская Мафия — Telegram-бот (aiogram 3)

## Запуск
Локально: `pip install -r requirements.txt` → `.env` из `.env.example` (нужен `BOT_TOKEN`) → `python main.py`
Docker (бот + PostgreSQL + Redis): `docker compose up -d --build`

В группе бот должен быть администратором с правом удалять сообщения и ограничивать участников
(иначе не работают мут и ночная тишина). Выключите у бота Privacy Mode в @BotFather.

## Игра
/startgame (/game), /begin, /leave, /players, /help — участники входят кнопкой и получают роль в ЛС.

## Администрирование
/warn /unwarn /mute /unmute /ban /unban /give /logs /stats /stopgame /onlyactive /forceactive /timers /setadmin /setowner
Таймеры: `/timers 120 60 60 45` (регистрация, ночь, день, голосование). Награды за игру — `game/constants.py`.
