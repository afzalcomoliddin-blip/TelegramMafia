from aiogram import F, Router
from aiogram.filters import Command
from aiogram.types import CallbackQuery, Message
from sqlalchemy.ext.asyncio import AsyncSession

from db.models import ItemType, Role, User
from handlers.common import safe_edit
from keyboards.main import roles_shop_kb, shop_kb
from services.shop import buy_item
from texts.ui import roles_shop_text, shop_text

router = Router()


@router.message(Command("shop"))
async def cmd_shop(message: Message, user: User) -> None:
    await message.answer(shop_text(user), reply_markup=shop_kb())


@router.callback_query(F.data.in_({"menu:shop", "shop:main"}))
async def cb_shop(cb: CallbackQuery, user: User) -> None:
    await safe_edit(cb, shop_text(user), shop_kb())
    await cb.answer()


@router.callback_query(F.data == "shop:roles")
async def cb_roles(cb: CallbackQuery, user: User) -> None:
    await safe_edit(cb, roles_shop_text(user), roles_shop_kb())
    await cb.answer()


@router.callback_query(F.data.startswith("shop:buy:"))
async def cb_buy(cb: CallbackQuery, user: User, session: AsyncSession) -> None:
    try:
        item = ItemType(cb.data.split(":")[2])
    except ValueError:
        await cb.answer("Товар не найден", show_alert=True)
        return
    _, msg = await buy_item(session, user, item)
    await cb.answer(msg, show_alert=True)
    await safe_edit(cb, shop_text(user), shop_kb())


@router.callback_query(F.data.startswith("shop:role:"))
async def cb_buy_role(cb: CallbackQuery, user: User, session: AsyncSession) -> None:
    try:
        role = Role(cb.data.split(":")[2])
    except ValueError:
        await cb.answer("Роль не найдена", show_alert=True)
        return
    _, msg = await buy_item(session, user, ItemType.ACTIVE_ROLE, role)
    await cb.answer(msg, show_alert=True)
    await safe_edit(cb, roles_shop_text(user), roles_shop_kb())
