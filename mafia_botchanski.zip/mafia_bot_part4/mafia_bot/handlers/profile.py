from aiogram import F, Router
from aiogram.filters import Command
from aiogram.types import CallbackQuery, Message
from sqlalchemy.ext.asyncio import AsyncSession

from db.models import User
from db.repo.users import get_items
from handlers.common import safe_edit
from keyboards.main import profile_kb
from texts.ui import profile_text

router = Router()


@router.message(Command("profile"))
async def cmd_profile(message: Message, user: User, session: AsyncSession) -> None:
    items = await get_items(session, user.id)
    await message.answer(profile_text(user, items), reply_markup=profile_kb(user))


@router.callback_query(F.data == "menu:profile")
async def cb_profile(cb: CallbackQuery, user: User, session: AsyncSession) -> None:
    items = await get_items(session, user.id)
    await safe_edit(cb, profile_text(user, items), profile_kb(user))
    await cb.answer()
