from aiogram import Bot, F, Router
from aiogram.exceptions import TelegramBadRequest
from aiogram.filters import Command, CommandObject, CommandStart
from aiogram.types import Message
from sqlalchemy.ext.asyncio import AsyncSession

from db.enums import GamePhase
from db.models import ChatSettings, Game, User
from db.repo.games import (
    get_active_game, get_chat_settings, get_players, get_seat, join_game, leave_game,
)
from game.constants import MIN_PLAYERS
from game.engine import registration_timer, start_game
from game.manager import manager
from keyboards.game import join_kb
from services.permissions import effective_level
from texts.common import mention
from texts.game import reg_text

router = Router()
GROUP = F.chat.type.in_({"group", "supergroup"})

JOIN_FAIL = {
    "already": "ℹ️ Вы уже записаны на эту игру.",
    "closed": "⏰ Регистрация на эту игру уже закрыта.",
    "full": "😕 В игре уже максимум игроков.",
    "busy": "⚠️ Вы уже участвуете в другой игре. Выйдите из неё командой /leave в том чате.",
}


async def refresh_reg(bot: Bot, session: AsyncSession, game: Game) -> None:
    s = manager.get(game.chat_id)
    if not s or not s.reg_message_id:
        return
    rows = await get_players(session, game.id)
    cs = await get_chat_settings(session, game.chat_id)
    try:
        await bot.edit_message_text(
            reg_text(game, rows, cs.registration_seconds),
            chat_id=game.chat_id, message_id=s.reg_message_id,
            reply_markup=await join_kb(bot, game.id, can_start=len(rows) >= MIN_PLAYERS),
        )
    except TelegramBadRequest:
        pass


async def manual_start(bot: Bot, session: AsyncSession, user: User, game: Game | None) -> str | None:
    """Досрочный старт. Возвращает текст ошибки или None, если игра запускается."""
    if game is None or game.phase != GamePhase.REGISTRATION:
        return "Регистрация уже закрыта."
    if game.creator_id != user.id and not effective_level(user):
        return "Начать игру может только создатель или администратор."
    rows = await get_players(session, game.id)
    if len(rows) < MIN_PLAYERS:
        return f"Нужно минимум {MIN_PLAYERS} игроков (сейчас {len(rows)})."
    manager.ensure(game.id, game.chat_id)
    manager.cancel_tasks(game.chat_id)  # снимаем таймер автостарта
    manager.spawn(game.chat_id, start_game(bot, game.id))
    return None


@router.message(Command("startgame", "game"), GROUP)
async def cmd_startgame(message: Message, user: User, session: AsyncSession, bot: Bot) -> None:
    chat = message.chat
    if await get_active_game(session, chat.id):
        await message.answer("🎮 В этом чате уже идёт игра или набор.")
        return
    cs = await get_chat_settings(session, chat.id, chat.title)
    game = Game(chat_id=chat.id, creator_id=user.id)
    session.add(game)
    await session.commit()

    s = manager.ensure(game.id, chat.id)
    msg = await message.answer(reg_text(game, [], cs.registration_seconds), reply_markup=await join_kb(bot, game.id))
    s.reg_message_id = msg.message_id
    manager.spawn(chat.id, registration_timer(bot, game.id, cs.registration_seconds))


@router.message(CommandStart(deep_link=True, magic=F.args.regexp(r"^join_\d+$")))
async def deep_join(message: Message, command: CommandObject, user: User, session: AsyncSession, bot: Bot) -> None:
    game = await session.get(Game, int(command.args[5:]))
    if game is None:
        await message.answer("❌ Игра не найдена.")
        return
    code = await join_game(session, game, user)
    if code != "ok":
        await message.answer(JOIN_FAIL[code])
        return
    cs = await session.get(ChatSettings, game.chat_id)
    where = f" в чате «{cs.title}»" if cs and cs.title else ""
    seat = await get_seat(session, game.id, user.id)
    await message.answer(
        f"✅ Вы присоединились к игре{where}!\n🔢 Ваш номер: <b>№{seat}</b>\n"
        "Роль и кнопки действий придут сюда, в личные сообщения."
    )
    await refresh_reg(bot, session, game)


@router.message(Command("begin"), GROUP)
async def cmd_begin(message: Message, user: User, session: AsyncSession, bot: Bot) -> None:
    game = await get_active_game(session, message.chat.id)
    err = await manual_start(bot, session, user, game)
    if err:
        await message.answer("⛔ " + err)


@router.message(Command("leave"), GROUP)
async def cmd_leave(message: Message, user: User, session: AsyncSession, bot: Bot) -> None:
    game = await get_active_game(session, message.chat.id)
    if not game or not await leave_game(session, game, user.id):
        await message.answer("ℹ️ Выйти можно только на этапе регистрации, если вы записаны.")
        return
    await message.answer(f"👋 {mention(user)} вышел из игры.")
    await refresh_reg(bot, session, game)


@router.message(Command("players"), GROUP)
async def cmd_players(message: Message, session: AsyncSession) -> None:
    game = await get_active_game(session, message.chat.id)
    if not game:
        await message.answer("ℹ️ Сейчас нет игры.")
        return
    rows = await get_players(session, game.id)
    names = "\n".join(f"{gp.seat}. {mention(u)}" for gp, u in rows) or "—"
    await message.answer(f"👥 <b>Игроки ({len(rows)}):</b>\n{names}")
