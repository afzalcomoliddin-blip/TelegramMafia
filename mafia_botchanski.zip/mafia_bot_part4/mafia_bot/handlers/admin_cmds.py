from aiogram import Bot, Router
from aiogram.filters import Command, CommandObject
from aiogram.types import Message
from sqlalchemy.ext.asyncio import AsyncSession

from db.models import User
from services.admin_exec import COMMAND_PERM, execute

router = Router()


@router.message(Command(*COMMAND_PERM))
async def generic_admin_cmd(
    message: Message, command: CommandObject, user: User, session: AsyncSession, bot: Bot
) -> None:
    reply_user = None
    r = message.reply_to_message
    if r and r.from_user and not r.from_user.is_bot:
        reply_user = await session.get(User, r.from_user.id)
    text = await execute(
        command.command, bot=bot, session=session, admin=user, chat_id=message.chat.id,
        args=(command.args or "").split(), reply_user=reply_user,
    )
    await message.answer(text)
