from aiogram import F, Router
from aiogram.filters import CommandStart
from aiogram.types import CallbackQuery, Message

from db.models import User
from handlers.common import safe_edit
from keyboards.main import main_menu
from texts.ui import start_text

router = Router()


@router.message(CommandStart())
async def cmd_start(message: Message, user: User) -> None:
    if message.chat.type != "private":
        await message.answer("🎭 Напишите мне в личные сообщения: /start — там профиль, магазин и помощь.")
        return
    await message.answer(start_text(user.full_name), reply_markup=main_menu())


@router.callback_query(F.data == "menu:main")
async def cb_main(cb: CallbackQuery, user: User) -> None:
    await safe_edit(cb, start_text(user.full_name), main_menu())
    await cb.answer()


@router.callback_query(F.data.in_({"game:create", "game:join"}))
async def cb_game_hint(cb: CallbackQuery) -> None:
    texts = {
        "game:create": "🎮 Добавьте меня в группу и напишите там /startgame — начнётся набор игроков.",
        "game:join": "🕹 Нажмите «Войти в игру» под сообщением о наборе в группе.",
    }
    await cb.answer(texts[cb.data], show_alert=True)
