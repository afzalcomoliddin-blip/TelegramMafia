import asyncio

from aiogram import Bot, F, Router
from aiogram.exceptions import TelegramBadRequest, TelegramForbiddenError
from aiogram.types import CallbackQuery
from sqlalchemy.ext.asyncio import AsyncSession

from db.enums import Role
from db.models import Game, User
from game.engine import spawn_announce
from game.manager import manager
from game.night import ACTING_ROLES, action_kind, allowed_targets
from game.state import Action
from game.voting import shown_voter
from handlers.game import manual_start
from keyboards.night import targets_kb

router = Router()


def _st(gid: int):
    s = manager.by_game(gid)
    return s.state if s else None


def _label(p) -> str:
    return f"{p.seat}. {p.raw}"


@router.callback_query(F.data.startswith("gs:"))
async def cb_start(cb: CallbackQuery, user: User, session: AsyncSession, bot: Bot) -> None:
    game = await session.get(Game, int(cb.data[3:]))
    err = await manual_start(bot, session, user, game)
    await cb.answer(err or "Игра начинается!", show_alert=bool(err))


# ───────── ночные действия ─────────
@router.callback_query(F.data.startswith("na:"))
async def cb_night(cb: CallbackQuery, bot: Bot) -> None:
    parts = cb.data.split(":")
    gid, kind = int(parts[1]), parts[2]
    st = _st(gid)
    if st is None or st.phase != "night":
        await cb.answer("Ночь уже закончилась.", show_alert=True)
        return
    p = st.players.get(cb.from_user.id)
    if p is None or not p.alive or p.role not in ACTING_ROLES:
        await cb.answer("Сейчас вы не можете ходить.", show_alert=True)
        return
    if p.uid in st.actions:
        await cb.answer("Вы уже сделали выбор.", show_alert=True)
        return

    if kind == "m":  # Комиссар: проверить / убить
        if p.role != Role.COMMISSAR:
            await cb.answer()
            return
        mode = parts[3]
        st.modes[p.uid] = mode
        items = [(u, _label(st.players[u])) for u in allowed_targets(st.players, p)]
        await cb.message.edit_text("🔍 Кого проверить?" if mode == "c" else "🔫 Кого убить?",
                                   reply_markup=targets_kb(gid, items))
        await cb.answer()
        return

    if kind == "b":
        if p.role != Role.ARSONIST or not p.marks:
            await cb.answer("Сначала отметьте хотя бы одного игрока.", show_alert=True)
            return
        st.actions[p.uid] = Action("burn_all")
        done = "🔥 Выбор принят: вы поджигаете всех отмеченных и себя."
    else:
        target = int(parts[3])
        if target not in allowed_targets(st.players, p):
            await cb.answer("Этого игрока выбрать нельзя.", show_alert=True)
            return
        mode = st.modes.get(p.uid)
        if p.role == Role.COMMISSAR and mode is None:
            await cb.answer("Сначала выберите действие.", show_alert=True)
            return
        ak = action_kind(p.role, mode)
        st.actions[p.uid] = Action(ak, target)
        t = st.players[target]
        done = f"✅ Выбор принят: {_label(t)}"
        if p.role == Role.COMMISSAR:
            done += " (проверка)" if ak == "check" else " (убийство)"
            for q in st.alive():  # Сержант видит выбор Комиссара
                if q.role == Role.SERGEANT:
                    try:
                        await bot.send_message(q.uid, f"👮 Комиссар выбрал <b>{t.name}</b> ({'проверка' if ak == 'check' else 'убийство'}).")
                    except (TelegramBadRequest, TelegramForbiddenError):
                        pass
    await cb.message.edit_text(done)
    await cb.answer()
    if st.expected <= set(st.actions):
        st.night_event.set()


@router.callback_query(F.data.startswith("mg:"))
async def cb_mage(cb: CallbackQuery) -> None:
    _, gid, att, act = cb.data.split(":")
    st = _st(int(gid))
    key = ("mg", cb.from_user.id, int(att))
    if st is None or key not in st.choice_expected or key in st.choices:
        await cb.answer("Выбор уже сделан или время вышло.", show_alert=True)
        return
    st.choices[key] = act
    await cb.message.edit_text("🕊 Вы помиловали нападавшего." if act == "p" else "💀 Вы приговорили нападавшего.")
    await cb.answer()
    if st.choice_expected <= set(st.choices):
        st.choice_event.set()


@router.callback_query(F.data.startswith("kz:"))
async def cb_kamikaze(cb: CallbackQuery) -> None:
    _, gid, tgt = cb.data.split(":")
    st = _st(int(gid))
    key = ("kz", cb.from_user.id)
    if st is None or key not in st.choice_expected or key in st.choices:
        await cb.answer("Выбор уже сделан или время вышло.", show_alert=True)
        return
    st.choices[key] = int(tgt)
    await cb.message.edit_text("💣 Выбор сделан.")
    await cb.answer()
    st.choice_event.set()


# ───────── голосование ─────────
@router.callback_query(F.data.startswith("vt:"))
async def cb_vote(cb: CallbackQuery, bot: Bot) -> None:
    _, gid, tgt = cb.data.split(":")
    st = _st(int(gid))
    if st is None or st.phase != "vote":
        await cb.answer("Голосование уже закончилось.", show_alert=True)
        return
    voter, target = cb.from_user.id, int(tgt)
    if voter not in st.eligible:
        await cb.answer("Вы не можете голосовать.", show_alert=True)
        return
    if voter in st.votes:
        await cb.answer("Вы уже проголосовали.", show_alert=True)
        return
    if target and (target == voter or target not in st.players or not st.players[target].alive):
        await cb.answer("Этого игрока выбрать нельзя.", show_alert=True)
        return
    st.votes[voter] = target
    who = shown_voter(st.players, voter)
    if target == 0:
        text = f"👤 <b>{who.name}</b> (№{who.seat}) проголосовал за пропуск"
        done = "✅ Голос принят: пропуск"
    else:
        t = st.players[target]
        text = f"👤 <b>{who.name}</b> (№{who.seat}) проголосовал за №{t.seat} (<b>{t.name}</b>)"
        done = f"✅ Голос принят: {_label(t)}"
    spawn_announce(bot, st, text)
    await cb.message.edit_text(done)
    await cb.answer()
    if st.eligible <= set(st.votes):
        st.vote_event.set()
