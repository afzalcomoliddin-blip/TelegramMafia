"""Контроль чата во время игры и ночной чат мафии. Регистрируется последним."""
from html import escape

from aiogram import Bot, F, Router
from aiogram.exceptions import TelegramBadRequest, TelegramForbiddenError
from aiogram.types import Message

from db.models import User
from game.constants import MAFIA_CHAT_ROLES
from game.manager import manager
from texts.roles import ROLE_NAMES

router = Router()


@router.message(F.chat.type.in_({"group", "supergroup"}))
async def guard_group(message: Message, user: User) -> None:
    s = manager.get(message.chat.id)
    st = s.state if s else None
    if st is None or st.phase == "finished":
        return
    p = st.players.get(user.id)
    if p is None:  # зрители пишут свободно
        return
    can = st.phase in ("day", "vote") and p.alive and user.id not in st.silenced
    if not can:
        try:
            await message.delete()
        except (TelegramBadRequest, TelegramForbiddenError):
            pass


@router.message(F.chat.type == "private", F.text, ~F.text.startswith("/"))
async def mafia_chat(message: Message, user: User, bot: Bot) -> None:
    st = manager.state_of_user(user.id)
    if st is None or st.phase != "night":
        return
    p = st.players.get(user.id)
    if p is None or not p.alive or p.role not in MAFIA_CHAT_ROLES:
        return
    who = f"@{p.username}" if p.username else p.name
    text = f"{ROLE_NAMES[p.role]} ({escape(who) if p.username else who}):\n{escape(message.text)}"
    for q in st.alive():
        if q.uid != p.uid and q.role in MAFIA_CHAT_ROLES:
            try:
                await bot.send_message(q.uid, text)
            except (TelegramBadRequest, TelegramForbiddenError):
                pass
