from aiogram import F, Router
from aiogram.filters import Command
from aiogram.types import CallbackQuery, InlineKeyboardMarkup, Message
from aiogram.utils.keyboard import InlineKeyboardBuilder

from handlers.common import safe_edit
from texts.help import BUTTONS, PAGES

router = Router()


def help_kb(page: str) -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    for key, title in BUTTONS:
        if key != page:
            b.button(text=title, callback_data=f"help:{key}")
    if page != "main":
        b.button(text="📖 К разделам", callback_data="help:main")
    b.button(text="⬅️ Меню", callback_data="menu:main")
    b.adjust(2)
    return b.as_markup()


@router.message(Command("help"))
async def cmd_help(message: Message) -> None:
    await message.answer(PAGES["main"], reply_markup=help_kb("main"))


@router.callback_query(F.data == "menu:help")
@router.callback_query(F.data.startswith("help:"))
async def cb_help(cb: CallbackQuery) -> None:
    page = cb.data.split(":")[1] if cb.data.startswith("help:") else "main"
    if page not in PAGES:
        page = "main"
    await safe_edit(cb, PAGES[page], help_kb(page))
    await cb.answer()
