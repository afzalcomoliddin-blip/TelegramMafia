from html import escape

from aiogram import Bot, F, Router
from aiogram.filters import Command, CommandObject
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import CallbackQuery, Message
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from config import OWNER_ID
from db.enums import AdminLevel, GamePhase
from db.models import Game, User
from db.repo.games import list_active_games
from db.repo.users import find_user
from handlers.common import safe_edit
from keyboards.admin import back_kb, broadcast_confirm_kb, force_active_kb, games_kb
from keyboards.main import admin_panel_kb
from services.admin_exec import (
    NO_RIGHTS, USAGE, do_forceactive, do_logs, do_onlyactive, do_stats, do_stop_game,
    execute, get_force_active,
)
from services.broadcast import start_broadcast
from services.logs import log_action
from services.permissions import ACTIONS, LEVEL_NAMES, effective_level, has_perm
from texts.ui import admin_panel_text

router = Router()
INPUT_ACTIONS = {"warn", "unwarn", "mute", "ban", "unban", "give"}


class AdminStates(StatesGroup):
    waiting_input = State()
    broadcast_msg = State()


def _not_command(m: Message) -> bool:
    return not (m.text or "").startswith("/")


# ───────── /setowner, /setadmin ─────────
@router.message(Command("setowner"))
async def cmd_setowner(message: Message, user: User, session: AsyncSession) -> None:
    if message.from_user.id != OWNER_ID:
        await message.answer(NO_RIGHTS)
        return
    user.admin_level = AdminLevel.OWNER
    await log_action(session, user.id, "setowner", user.id)
    await session.commit()
    await message.answer("👑 Права владельца подтверждены.")


@router.message(Command("setadmin"))
async def cmd_setadmin(message: Message, command: CommandObject, user: User, session: AsyncSession) -> None:
    actor = effective_level(user)
    if actor < AdminLevel.COOWNER:
        await message.answer(NO_RIGHTS)
        return
    parts = (command.args or "").split()
    reply = message.reply_to_message
    if reply and reply.from_user and not reply.from_user.is_bot:
        target = await session.get(User, reply.from_user.id)
        level_arg = parts[0] if parts else None
    else:
        target = await find_user(session, parts[0]) if parts else None
        level_arg = parts[1] if len(parts) > 1 else None
    if level_arg is None or not level_arg.isdigit() or int(level_arg) > 5:
        await message.answer(
            "ℹ️ <code>/setadmin &lt;id|@username&gt; &lt;0-5&gt;</code> или ответом на сообщение:\n"
            "0 игрок · 1 модератор · 2 мл. админ · 3 админ · 4 ст. админ · 5 совладелец"
        )
        return
    if target is None:
        await message.answer("❌ Пользователь не найден (он должен хотя бы раз написать боту).")
        return
    new_level = AdminLevel(int(level_arg))
    if target.id in (OWNER_ID, user.id):
        await message.answer(NO_RIGHTS)
        return
    if effective_level(target) >= actor or new_level >= actor:
        await message.answer("⛔ Можно управлять только уровнями ниже вашего.")
        return
    old = target.admin_level
    target.admin_level = new_level
    await log_action(session, user.id, "setadmin", target.id, f"{old.name} -> {new_level.name}")
    await session.commit()
    await message.answer(f"✅ {escape(target.full_name)} (<code>{target.id}</code>) — <b>{LEVEL_NAMES[new_level]}</b>")


# ───────── отмена любого ввода ─────────
@router.message(Command("cancel"))
async def cmd_cancel(message: Message, state: FSMContext) -> None:
    await state.clear()
    await message.answer("❎ Отменено.")


# ───────── панель ─────────
@router.callback_query(F.data == "admin:panel")
async def cb_panel(cb: CallbackQuery, user: User, state: FSMContext) -> None:
    if not effective_level(user):
        await cb.answer(NO_RIGHTS, show_alert=True)
        return
    await state.clear()
    await safe_edit(cb, admin_panel_text(user), admin_panel_kb(user))
    await cb.answer()


@router.callback_query(F.data.startswith("admin:act:"))
async def cb_action(cb: CallbackQuery, user: User, session: AsyncSession, state: FSMContext) -> None:
    action = cb.data.split(":")[2]
    if action not in ACTIONS or not has_perm(user, action):
        await cb.answer(NO_RIGHTS, show_alert=True)
        return

    if action in INPUT_ACTIONS:
        await state.set_state(AdminStates.waiting_input)
        await state.update_data(cmd=action)
        await safe_edit(cb, USAGE[action] + "\n\n✍️ Отправьте данные одним сообщением. /cancel — отмена.", back_kb())
    elif action == "stats":
        await safe_edit(cb, await do_stats(session), back_kb())
    elif action == "logs":
        await safe_edit(cb, await do_logs(session, 15), back_kb())
    elif action == "forceactive":
        on = await get_force_active(session)
        await safe_edit(cb, f"🔥 <b>Новые игры без «Мирных жителей»</b>\nСейчас: <b>{'вкл' if on else 'выкл'}</b>", force_active_kb())
    elif action in ("stop_game", "onlyactive"):
        rows = await list_active_games(session)
        if not rows:
            await cb.answer("Активных игр нет", show_alert=True)
            return
        if action == "stop_game":
            await safe_edit(cb, "🛑 <b>Какую игру остановить?</b>", games_kb(rows, "admin:stop"))
        else:
            await safe_edit(cb, "🎯 <b>Только активные роли</b>\nНажмите на игру, чтобы переключить режим (до старта).", games_kb(rows, "admin:oa"))
    elif action == "timers":
        await safe_edit(cb, USAGE["timers"], back_kb())
    elif action == "broadcast":
        await state.set_state(AdminStates.broadcast_msg)
        await safe_edit(cb, "📢 <b>Рассылка</b>\nОтправьте сообщение (текст, фото, видео…) — я разошлю его всем. /cancel — отмена.", back_kb())
    await cb.answer()


@router.callback_query(F.data.startswith("admin:fa:"))
async def cb_force_active(cb: CallbackQuery, user: User, session: AsyncSession) -> None:
    if not has_perm(user, "forceactive"):
        await cb.answer(NO_RIGHTS, show_alert=True)
        return
    enable = cb.data.endswith(":on")
    await do_forceactive(session, user, enable)
    await safe_edit(cb, f"🔥 <b>Новые игры без «Мирных жителей»</b>\nСейчас: <b>{'вкл' if enable else 'выкл'}</b>", force_active_kb())
    await cb.answer("Готово")


@router.callback_query(F.data.startswith(("admin:stop:", "admin:oa:")))
async def cb_game_action(cb: CallbackQuery, user: User, session: AsyncSession, bot: Bot) -> None:
    _, kind, gid = cb.data.split(":")
    if not has_perm(user, "stop_game" if kind == "stop" else "onlyactive"):
        await cb.answer(NO_RIGHTS, show_alert=True)
        return
    game = await session.get(Game, int(gid))
    if game is None or game.phase == GamePhase.FINISHED:
        await cb.answer("Игра уже завершена", show_alert=True)
        return
    if kind == "stop":
        text = await do_stop_game(bot, session, user, game)
    else:
        text = await do_onlyactive(bot, session, user, game, enable=not game.only_active)
    await cb.answer()
    await safe_edit(cb, text, back_kb())


# ───────── ввод для действий панели ─────────
@router.message(AdminStates.waiting_input, _not_command)
async def fsm_input(message: Message, user: User, session: AsyncSession, state: FSMContext, bot: Bot) -> None:
    cmd = (await state.get_data()).get("cmd")
    await state.clear()
    text = await execute(cmd, bot=bot, session=session, admin=user, chat_id=message.chat.id,
                         args=(message.text or "").split())
    await message.answer(text, reply_markup=back_kb())


# ───────── рассылка ─────────
@router.message(AdminStates.broadcast_msg, _not_command)
async def bc_receive(message: Message, user: User, session: AsyncSession, state: FSMContext) -> None:
    if not has_perm(user, "broadcast"):
        await state.clear()
        await message.answer(NO_RIGHTS)
        return
    total = (await session.execute(select(func.count()).select_from(User).where(User.is_banned.is_(False)))).scalar_one()
    await state.update_data(chat_id=message.chat.id, msg_id=message.message_id)
    await message.reply(f"📢 Отправить это сообщение <b>{total}</b> пользователям?", reply_markup=broadcast_confirm_kb())


@router.callback_query(F.data.in_({"bc:yes", "bc:no"}))
async def bc_confirm(cb: CallbackQuery, user: User, state: FSMContext, bot: Bot) -> None:
    data = await state.get_data()
    await state.clear()
    if cb.data == "bc:no" or not data.get("msg_id"):
        await safe_edit(cb, "❌ Рассылка отменена.")
    elif not has_perm(user, "broadcast"):
        await safe_edit(cb, NO_RIGHTS)
    else:
        start_broadcast(bot, user.id, data["chat_id"], data["msg_id"])
        await safe_edit(cb, "📢 Рассылка запущена. Пришлю отчёт, когда закончу.")
    await cb.answer()
