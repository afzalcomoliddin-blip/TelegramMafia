from dataclasses import dataclass

from db.enums import Role, Team
from game.constants import MAFIA_SIDE
from game.state import P
from texts.roles import ROLE_TEAM

SURVIVORS = {Role.SWINDLER, Role.SNITCH, Role.MAGE, Role.ALCHEMIST}  # цель — дожить до конца


@dataclass
class WinResult:
    team: Team | None
    title: str
    winners: set[int]


def _peace_side(p: P) -> bool:
    if p.orig_role == Role.WEREWOLF:  # Оборотень побеждает только за Мирных
        return True
    return ROLE_TEAM[p.role] == Team.PEACE and p.role != Role.SUICIDE


def check_win(players: dict[int, P], extra: set[int]) -> WinResult | None:
    alive = [p for p in players.values() if p.alive]
    if not alive:
        return WinResult(None, "🤝 Ничья — в городе никого не осталось.", set(extra))
    mafia = [p for p in alive if p.role in MAFIA_SIDE]
    maniac = [p for p in alive if p.role == Role.MANIAC]
    arson = [p for p in alive if p.role == Role.ARSONIST]
    others = len(alive) - len(mafia)

    team = title = None
    if not mafia and not maniac and not arson:
        team, title = Team.PEACE, "🕊 Победа мирных жителей!"
    elif mafia and len(mafia) >= others:
        team, title = Team.MAFIA, "🤵 Победа мафии!"
    elif not mafia and maniac and len(alive) <= 2:
        team, title = Team.NEUTRAL, "🔪 Победил Маньяк!"
    elif not mafia and not maniac and arson and len(alive) <= 2:
        team, title = Team.NEUTRAL, "🧟 Победил Поджигатель!"
    if team is None:
        return None

    winners = set(extra)
    for p in players.values():
        if team == Team.PEACE and _peace_side(p):
            winners.add(p.uid)
        elif team == Team.MAFIA and p.role in MAFIA_SIDE and p.orig_role != Role.WEREWOLF:
            winners.add(p.uid)
        elif team == Team.NEUTRAL and p.alive and p.role in (Role.MANIAC, Role.ARSONIST):
            winners.add(p.uid)
        if p.alive and p.role in SURVIVORS:
            winners.add(p.uid)
    return WinResult(team, title, winners)
