"""Динамическая раздача ролей. Чистая логика без БД и Telegram — легко тестировать."""
import random
from collections.abc import Sequence

from db.enums import Role
from game.constants import ACTIVE_ROLES, MAX_PLAYERS, MIN_PLAYERS, PASSIVE_PEACE
from texts.roles import ROLE_TEAM

R = Role
# При 5 игроках состав фиксирован
BASE = [R.DON, R.COMMISSAR, R.DOCTOR, R.CITIZEN, R.CITIZEN]
# Каждый следующий игрок (6-й, 7-й … 30-й) добавляет роль: чем больше людей — тем больше активных и нейтральных
ADDITIONS = [
    R.MAFIA, R.LOVER, R.SERGEANT, R.MANIAC, R.LAWYER, R.HOBO, R.MAYOR, R.MAFIA, R.LUCKY,
    R.KILLER, R.ARSONIST, R.KAMIKAZE, R.JOURNALIST, R.MAGE, R.SWINDLER, R.MAFIA, R.SNITCH,
    R.CITIZEN, R.WEREWOLF, R.SUICIDE, R.ALCHEMIST, R.MAFIA, R.CITIZEN, R.CITIZEN, R.CITIZEN,
]
assert len(BASE) + len(ADDITIONS) == MAX_PLAYERS

_REPL_ACTIVE = [R.SERGEANT, R.LOVER, R.HOBO, R.SNITCH, R.SWINDLER, R.MAGE, R.ALCHEMIST, R.MANIAC, R.ARSONIST]
_REPL_PASSIVE = [R.LUCKY, R.MAYOR, R.KAMIKAZE, R.SUICIDE]
_DUPES = [R.DOCTOR, R.HOBO, R.LOVER]  # запас для /onlyactive, когда свободные активные роли кончились

# Какую роль «выдавить» из состава, если купленной роли в нём нет
_VICTIMS = {
    "peace": [R.CITIZEN, R.LUCKY, R.MAYOR, R.KAMIKAZE, R.SUICIDE],
    "mafia": [R.MAFIA, R.CITIZEN],
    "neutral": [R.CITIZEN, R.SUICIDE, R.LUCKY, R.MAYOR, R.KAMIKAZE],
}


def _replace(pool: list[Role], victims: set[Role], *, allow_passive: bool, allow_dupes: bool) -> list[Role]:
    pool = list(pool)
    queue = [r for r in _REPL_ACTIVE if r not in pool]
    if allow_passive:
        queue += [r for r in _REPL_PASSIVE if r not in pool]
    d = 0
    for i, role in enumerate(pool):
        if role not in victims:
            continue
        if queue:
            pool[i] = queue.pop(0)
        elif allow_dupes:
            pool[i] = _DUPES[d % len(_DUPES)]
            d += 1
    return pool


def build_pool(n: int, *, only_active: bool = False, no_citizens: bool = False) -> list[Role]:
    """Состав ролей на n игроков. only_active — /onlyactive, no_citizens — /forceactive."""
    if not MIN_PLAYERS <= n <= MAX_PLAYERS:
        raise ValueError(f"Игроков должно быть от {MIN_PLAYERS} до {MAX_PLAYERS}")
    pool = (BASE + ADDITIONS)[:n]
    if n > MIN_PLAYERS:
        if only_active:
            pool = _replace(pool, PASSIVE_PEACE, allow_passive=False, allow_dupes=True)
        elif no_citizens:
            pool = _replace(pool, {R.CITIZEN}, allow_passive=True, allow_dupes=False)
    return pool


def _make_room(pool: list[Role], role: Role) -> bool:
    for victim in _VICTIMS[ROLE_TEAM[role].value]:
        if victim in pool:
            pool[pool.index(victim)] = role
            return True
    return False


def assign_roles(
    player_ids: Sequence[int],
    purchases: Sequence[tuple[int, Role]] = (),
    *,
    only_active: bool = False,
    no_citizens: bool = False,
    rng: random.Random | None = None,
) -> tuple[dict[int, Role], dict[int, Role]]:
    """Возвращает (роли игроков, {user_id: купленная роль, которая сработала}).

    Купившие одну роль: выигрывает случайный. Проигравшие и неподошедшие покупки не расходуются.
    При 5 игроках покупки не действуют (состав фиксирован).
    """
    rng = rng or random.Random()
    ids = list(player_ids)
    pool = build_pool(len(ids), only_active=only_active, no_citizens=no_citizens)
    assigned: dict[int, Role] = {}
    consumed: dict[int, Role] = {}

    if len(ids) > MIN_PLAYERS and purchases:
        buyers_by_role: dict[Role, list[int]] = {}
        for uid, role in purchases:
            if uid in ids and role in ACTIVE_ROLES:
                buyers_by_role.setdefault(role, []).append(uid)
        roles = list(buyers_by_role)
        rng.shuffle(roles)
        for role in roles:
            buyers = [u for u in dict.fromkeys(buyers_by_role[role]) if u not in assigned]
            if not buyers:
                continue
            if role not in pool and not _make_room(pool, role):
                continue
            winner = rng.choice(buyers)
            pool.remove(role)
            assigned[winner] = consumed[winner] = role

    free = [u for u in ids if u not in assigned]
    rng.shuffle(free)
    rng.shuffle(pool)
    assigned.update(zip(free, pool))
    return assigned, consumed
