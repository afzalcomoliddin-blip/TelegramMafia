import asyncio
import logging
from dataclasses import dataclass, field

log = logging.getLogger(__name__)


@dataclass
class GameSession:
    """Рантайм-состояние игры в чате (в памяти). Данные игры хранятся в БД."""
    game_id: int
    chat_id: int
    reg_message_id: int | None = None
    tasks: set = field(default_factory=set)
    state: object | None = None  # game.state.GameState
    starting: bool = False


def _done(task: asyncio.Task) -> None:
    if not task.cancelled() and task.exception():
        log.error("game task failed", exc_info=task.exception())


class GameManager:
    def __init__(self) -> None:
        self._sessions: dict[int, GameSession] = {}

    def get(self, chat_id: int) -> GameSession | None:
        return self._sessions.get(chat_id)

    def ensure(self, game_id: int, chat_id: int) -> GameSession:
        s = self._sessions.get(chat_id)
        if s is None or s.game_id != game_id:
            if s:
                self.cancel_tasks(chat_id)
            s = self._sessions[chat_id] = GameSession(game_id, chat_id)
        return s

    def spawn(self, chat_id: int, coro) -> asyncio.Task:
        s = self._sessions[chat_id]
        task = asyncio.create_task(coro)
        s.tasks.add(task)
        task.add_done_callback(s.tasks.discard)
        task.add_done_callback(_done)
        return task

    def cancel_tasks(self, chat_id: int) -> None:
        s = self._sessions.get(chat_id)
        if not s:
            return
        current = asyncio.current_task()
        for t in list(s.tasks):
            if t is not current:
                t.cancel()

    def by_game(self, game_id: int):
        for s in self._sessions.values():
            if s.game_id == game_id:
                return s
        return None

    def state_of_user(self, uid: int):
        for s in self._sessions.values():
            st = s.state
            if st is not None and uid in st.players and st.phase != "finished":
                return st
        return None

    def drop(self, chat_id: int) -> None:
        self.cancel_tasks(chat_id)
        self._sessions.pop(chat_id, None)


manager = GameManager()
