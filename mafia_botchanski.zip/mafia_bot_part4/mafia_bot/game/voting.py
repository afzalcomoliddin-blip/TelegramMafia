from dataclasses import dataclass

from db.enums import Role
from game.state import P


@dataclass
class VoteOutcome:
    hanged: int | None
    reason: str  # hanged | none | tie | skip | protected
    totals: dict[int, int]  # target uid (0 = пропуск) -> сумма голосов


def shown_voter(players: dict[int, P], voter: int) -> P:
    """Под чьим именем голосует игрок (Аферист — под выбранным)."""
    v = players[voter]
    if v.role == Role.SWINDLER and v.disguise in players:
        return players[v.disguise]
    return v


def vote_weight(players: dict[int, P], voter: int) -> int:
    return 2 if shown_voter(players, voter).role == Role.MAYOR else 1


def tally(players: dict[int, P], votes: dict[int, int]) -> VoteOutcome:
    totals: dict[int, int] = {}
    for voter, target in votes.items():
        totals[target] = totals.get(target, 0) + vote_weight(players, voter)
    cands = {t: w for t, w in totals.items() if t != 0}
    if not cands:
        return VoteOutcome(None, "none", totals)
    top = max(cands.values())
    leaders = [t for t, w in cands.items() if w == top]
    if len(leaders) > 1:
        return VoteOutcome(None, "tie", totals)
    if totals.get(0, 0) >= top:
        return VoteOutcome(None, "skip", totals)
    p = players[leaders[0]]
    if p.protected:  # Адвокат
        return VoteOutcome(None, "protected", totals)
    if p.vote_shield:  # предмет «Защита от голосования»
        p.vote_shield = False
        return VoteOutcome(None, "protected", totals)
    return VoteOutcome(leaders[0], "hanged", totals)
