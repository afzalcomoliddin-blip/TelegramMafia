"""Игровой движок: регистрация → роли → ночь → день → голосование → победа."""
import asyncio
import html
import logging

from aiogram import Bot
from aiogram.exceptions import TelegramBadRequest, TelegramForbiddenError, TelegramRetryAfter
from sqlalchemy import select, update
from sqlalchemy.ext.asyncio import AsyncSession

from db.enums import GamePhase, ItemType, Role, Team
from db.models import BotSettings, ChatSettings, Game, GamePlayer, UserItem
from db.repo.games import get_players, renumber_seats
from db.session import SessionMaker
from game.constants import (
    ITEM_FLAGS, MAFIA_CHAT_ROLES, MAFIA_TEAM_VISIBLE, MIN_PLAYERS,
    DAY_SECONDS, NIGHT_SECONDS, REGISTRATION_SECONDS, REWARD_PLAY, REWARD_WIN, VOTE_SECONDS,
)
from game.distribution import assign_roles
from game.manager import manager
from game.night import ACTING_ROLES, allowed_targets, apply_outcome, resolve_night
from game.state import GameState, P
from game.voting import shown_voter, tally
from keyboards.night import commissar_kb, kamikaze_kb, mage_kb, open_bot_kb, targets_kb, vote_kb
from texts.game import alive_text, composition_text, deaths_text, final_text, night_report_text, role_message
from texts.roles import ROLE_NAMES, ROLE_TEAM
from utils import utcnow
from game.win import check_win

log = logging.getLogger(__name__)
R = Role

PROMPTS = {
    R.DOCTOR: "💉 <b>Доктор</b>, кого лечим этой ночью?",
    R.LOVER: "💃 <b>Любовница</b>, к кому идёте?",
    R.HOBO: "🧙 <b>Бомж</b>, к кому идёте за бутылкой?",
    R.DON: "🤵 <b>Дон</b>, кого убить этой ночью?",
    R.LAWYER: "🧑‍💼 <b>Адвокат</b>, кого защитить?",
    R.KILLER: "🕴 <b>Убийца</b>, кого убить?",
    R.JOURNALIST: "👩‍💻 <b>Журналист</b>, за кем следим?",
    R.MANIAC: "🔪 <b>Маньяк</b>, кого убить?",
    R.ARSONIST: "🧟 <b>Поджигатель</b>, кого отметить огнём?",
    R.SWINDLER: "🤹 <b>Аферист</b>, к кому зайдёте (днём голосуете под его именем)?",
    R.SNITCH: "🤓 <b>Стукач</b>, кого проверяем?",
    R.ALCHEMIST: "⚗️ <b>Алхимик</b>, над кем проводим эксперимент?",
}
_bg: set[asyncio.Task] = set()


# ───────── вспомогательное ─────────
async def _send(bot: Bot, chat_id: int, text: str, **kw):
    for _ in range(3):
        try:
            return await bot.send_message(chat_id, text, **kw)
        except TelegramRetryAfter as e:
            await asyncio.sleep(e.retry_after + 0.5)
        except (TelegramForbiddenError, TelegramBadRequest):
            return None
    return None


async def _edit(bot: Bot, chat_id: int, message_id: int, text: str) -> None:
    try:
        await bot.edit_message_text(text, chat_id=chat_id, message_id=message_id)
    except (TelegramBadRequest, TelegramForbiddenError):
        pass


async def announce(bot: Bot, st: GameState, text: str) -> None:
    """Последовательные анонсы в группу (защита от флуд-лимита)."""
    async with st.lock:
        await _send(bot, st.chat_id, text)
        await asyncio.sleep(0.35)


def spawn_announce(bot: Bot, st: GameState, text: str) -> None:
    t = asyncio.create_task(announce(bot, st, text))
    _bg.add(t)
    t.add_done_callback(_bg.discard)


def _label(p: P) -> str:
    return f"{p.seat}. {p.raw}"


async def _set_phase(st: GameState, phase: GamePhase) -> None:
    async with SessionMaker() as session:
        await session.execute(update(Game).where(Game.id == st.game_id).values(phase=phase, day_number=st.day))
        await session.commit()


async def _sync(st: GameState) -> None:
    async with SessionMaker() as session:
        for p in st.players.values():
            await session.execute(update(GamePlayer).where(GamePlayer.id == p.gp_id).values(
                role=p.role, is_alive=p.alive, has_shield=p.shield, has_rifle=p.rifle,
                has_killer_shield=p.killer_shield, has_vote_shield=p.vote_shield,
                self_heal_used=p.self_heal_used, self_protect_used=p.self_protect_used,
                last_target_id=p.last_target, ignited_count=len(p.marks), swindler_name_of=p.disguise,
            ))
        await session.commit()


async def _close_reg(bot: Bot, chat_id: int, text: str) -> None:
    s = manager.get(chat_id)
    if s and s.reg_message_id:
        try:
            await bot.edit_message_text(text, chat_id=chat_id, message_id=s.reg_message_id, reply_markup=None)
            return
        except TelegramBadRequest:
            pass
    await _send(bot, chat_id, text)


# ───────── регистрация и старт ─────────
async def registration_timer(bot: Bot, game_id: int, seconds: int = REGISTRATION_SECONDS) -> None:
    await asyncio.sleep(seconds)
    await start_game(bot, game_id)


async def start_game(bot: Bot, game_id: int) -> None:
    try:
        await _start_game(bot, game_id)
    except asyncio.CancelledError:
        raise
    except Exception:
        log.exception("start_game failed (game %s)", game_id)


async def _start_game(bot: Bot, game_id: int) -> None:
    async with SessionMaker() as session:
        game = await session.get(Game, game_id)
        if game is None or game.phase != GamePhase.REGISTRATION:
            return
        chat_id = game.chat_id
        s = manager.ensure(game_id, chat_id)
        if s.starting:
            return
        s.starting = True
        rows = await get_players(session, game_id)

        if len(rows) < MIN_PLAYERS:
            game.phase, game.finished_at = GamePhase.FINISHED, utcnow()
            await session.commit()
            await _close_reg(bot, chat_id, f"😔 Игра отменена: набралось меньше {MIN_PLAYERS} игроков.")
            manager.drop(chat_id)
            return

        await renumber_seats(session, game_id)
        rows = await get_players(session, game_id)
        settings = await session.get(BotSettings, 1)
        ids = [u.id for _, u in rows]
        items = list((await session.execute(select(UserItem).where(UserItem.user_id.in_(ids)))).scalars())
        purchases = [(it.user_id, it.role) for it in items
                     if it.item == ItemType.ACTIVE_ROLE and it.role and it.amount > 0]
        assigned, consumed = assign_roles(
            ids, purchases, only_active=game.only_active,
            no_citizens=bool(settings and settings.force_active),
        )
        by_user: dict[int, list[UserItem]] = {}
        for it in items:
            by_user.setdefault(it.user_id, []).append(it)
        for gp, u in rows:
            gp.role = gp.original_role = assigned[u.id]
            for it in by_user.get(u.id, []):
                if it.amount <= 0:
                    continue
                if it.item in ITEM_FLAGS:  # предметы расходуются на игру
                    setattr(gp, ITEM_FLAGS[it.item], True)
                    it.amount -= 1
                elif it.item == ItemType.ACTIVE_ROLE and consumed.get(u.id) == it.role:
                    it.amount -= 1
        for it in items:
            if it.amount <= 0:
                await session.delete(it)
        game.phase, game.day_number, game.started_at = GamePhase.NIGHT, 1, utcnow()
        await session.commit()

        players = {
            u.id: P(uid=u.id, seat=gp.seat, name=html.escape(u.full_name), raw=u.full_name, username=u.username,
                    role=gp.role, orig_role=gp.original_role, gp_id=gp.id, documents=gp.has_documents,
                    shield=gp.has_shield, mask=gp.has_mask, rifle=gp.has_rifle,
                    killer_shield=gp.has_killer_shield, vote_shield=gp.has_vote_shield)
            for gp, u in rows
        }
        me = await bot.me()
        cs = await session.get(ChatSettings, chat_id)
        s.state = GameState(
            game_id, chat_id, players, bot_username=me.username,
            night_seconds=cs.night_seconds if cs else NIGHT_SECONDS,
            day_seconds=cs.day_seconds if cs else DAY_SECONDS,
            vote_seconds=cs.vote_seconds if cs else VOTE_SECONDS,
        )

        await _close_reg(bot, chat_id, f"🎮 <b>Игра началась!</b> Игроков: {len(rows)}")
        team = [(g, u) for g, u in rows if g.role in MAFIA_TEAM_VISIBLE]
        failed = []
        for gp, u in rows:
            mates = [(g, x) for g, x in team if x.id != u.id] if gp.role in MAFIA_TEAM_VISIBLE else []
            if not await _send(bot, u.id, role_message(gp, mates)):
                failed.append(u.full_name)
            await asyncio.sleep(0.05)
        text = composition_text(rows)
        if failed:
            text += "\n\n⚠️ Не удалось написать в ЛС: " + html.escape(", ".join(failed))
        await _send(bot, chat_id, text, reply_markup=open_bot_kb(me.username))
        manager.spawn(chat_id, run_game(bot, game_id))


# ───────── основной цикл ─────────
async def run_game(bot: Bot, game_id: int) -> None:
    s = manager.by_game(game_id)
    st = s.state if s else None
    if st is None:
        return
    try:
        while True:
            res, items, acted, missed = await _night(bot, st)
            await _sync(st)
            await _send(bot, st.chat_id, night_report_text(acted, missed))
            text = deaths_text(items)
            if res.public:
                text += "\n\n" + "\n".join(res.public)
            await _send(bot, st.chat_id, text)
            if await _try_finish(bot, st):
                return
            await _day(bot, st)
            await _sync(st)
            if await _try_finish(bot, st):
                return
            st.day += 1
    except asyncio.CancelledError:
        st.phase = "finished"
        raise
    except Exception:
        log.exception("game %s crashed", game_id)
        st.phase = "finished"
        await _send(bot, st.chat_id, "⚠️ Ошибка в игровом движке — игра остановлена. Начать новую: /startgame")
        async with SessionMaker() as session:
            await session.execute(update(Game).where(Game.id == game_id)
                                  .values(phase=GamePhase.FINISHED, finished_at=utcnow()))
            await session.commit()
        manager.drop(st.chat_id)


# ───────── ночь ─────────
async def _prompt(bot: Bot, st: GameState, p: P) -> None:
    r = p.role
    if r == R.MAFIA:
        await _send(bot, p.uid, f"🌙 Ночь {st.day}. 🤝 Пишите мне — ваши сообщения увидит команда мафии (Дон и Мафия).")
        return
    if r not in ACTING_ROLES:
        return
    if r == R.COMMISSAR:
        msg = await _send(bot, p.uid, f"🕵️ <b>Ночь {st.day}.</b> Что делает Комиссар?", reply_markup=commissar_kb(st.game_id))
    else:
        targets = allowed_targets(st.players, p)
        burn = r == R.ARSONIST and bool(p.marks)
        if not targets and not burn:
            return
        text = PROMPTS[r]
        if r == R.ARSONIST:
            text += f"\nОтмечено игроков: {len(p.marks)}"
        if r in MAFIA_CHAT_ROLES:
            text += "\n🤝 Можно писать мне — сообщения увидит команда мафии."
        msg = await _send(bot, p.uid, f"{text}\n⏳ {st.night_seconds} сек.",
                          reply_markup=targets_kb(st.game_id, [(u, _label(st.players[u])) for u in targets], burn))
    if msg:
        st.prompt_msgs[p.uid] = msg.message_id
        st.expected.add(p.uid)


async def _night(bot: Bot, st: GameState):
    st.phase = "night"
    st.actions.clear(); st.modes.clear(); st.expected = set(); st.prompt_msgs.clear()
    st.night_event.clear(); st.silenced = set()
    await _set_phase(st, GamePhase.NIGHT)
    await _send(bot, st.chat_id,
                f"🌙 <b>Наступила ночь {st.day}</b>\nГород засыпает. Активные роли — откройте бота: "
                f"все ходы делаются в личных сообщениях ({st.night_seconds} сек.).",
                reply_markup=open_bot_kb(st.bot_username))
    for p in st.alive():
        await _prompt(bot, st, p)
        await asyncio.sleep(0.03)
    if st.expected:
        try:
            await asyncio.wait_for(st.night_event.wait(), st.night_seconds)
        except asyncio.TimeoutError:
            pass
    else:
        await asyncio.sleep(10)
    st.phase = "resolve"
    for uid, mid in st.prompt_msgs.items():
        if uid not in st.actions:
            await _edit(bot, uid, mid, "⌛ Время вышло — вы пропустили ход.")

    acted = [st.players[u].role for u in st.actions]
    missed = len(st.expected - set(st.actions))
    res = resolve_night(st.players, st.actions)
    for u, a in st.actions.items():
        if st.players[u].role == R.MANIAC and a.kind == "kill":
            st.players[u].last_target = a.target
    for uid, lines in res.dms.items():
        for line in lines:
            await _send(bot, uid, line)
    await _mage_phase(bot, st, res)

    before = {u: p.role for u, p in st.players.items()}
    items = [(st.players[u].name, before[u], [before[b] for b in d.by if b in before and b != u], d.cause)
             for u, d in res.deaths.items()]
    notes = apply_outcome(st.players, list(res.deaths), res.transforms)
    for uid, text in notes:
        await _send(bot, uid, text)
    st.silenced = set(res.silenced)
    st.extra_winners |= res.winners
    return res, items, acted, missed


async def _mage_phase(bot: Bot, st: GameState, res) -> None:
    prompts = [(m, a) for m, a in dict.fromkeys(res.mage_prompts) if st.players[m].alive]
    if not prompts:
        return
    st.choices.clear(); st.choice_expected = set(); st.choice_event.clear()
    for m, a in prompts:
        ap = st.players[a]
        msg = await _send(bot, m, f"🧙 <b>Вас пытались убить!</b> Нападавший: {ROLE_NAMES[ap.role]} "
                                  f"<b>{ap.name}</b> (№{ap.seat}). Попытка тщетна — что сделаете?",
                          reply_markup=mage_kb(st.game_id, a))
        if msg:
            st.choice_expected.add(("mg", m, a))
    if st.choice_expected:
        try:
            await asyncio.wait_for(st.choice_event.wait(), 25)
        except asyncio.TimeoutError:
            pass
    for (kind, m, a), val in st.choices.items():
        if kind == "mg" and val == "k" and st.players[a].alive:
            res.kill(a, "mage", [m])


# ───────── день и голосование ─────────
async def _day(bot: Bot, st: GameState) -> None:
    st.phase = "day"
    await _set_phase(st, GamePhase.DAY)
    await _send(bot, st.chat_id, alive_text(st.alive(), st.day_seconds))
    await asyncio.sleep(st.day_seconds)
    await _vote(bot, st)


async def _vote(bot: Bot, st: GameState) -> None:
    st.phase = "vote"
    await _set_phase(st, GamePhase.VOTING)
    st.votes.clear(); st.vote_event.clear()
    alive = st.alive()
    st.eligible = {p.uid for p in alive if p.uid not in st.silenced}
    await _send(bot, st.chat_id, f"🗳 <b>Голосование началось</b>\nГолосуйте в личных сообщениях с ботом ({st.vote_seconds} сек.).",
                reply_markup=open_bot_kb(st.bot_username))
    for p in alive:
        if p.uid in st.eligible:
            items = [(q.uid, _label(q)) for q in alive if q.uid != p.uid]
            await _send(bot, p.uid, f"🗳 <b>День {st.day}.</b> За кого голосуем?\n⏳ {st.vote_seconds} сек.",
                        reply_markup=vote_kb(st.game_id, items))
            await asyncio.sleep(0.03)
    if st.eligible:
        try:
            await asyncio.wait_for(st.vote_event.wait(), st.vote_seconds)
        except asyncio.TimeoutError:
            pass
    else:
        await asyncio.sleep(3)
    st.phase = "resolve"
    await asyncio.sleep(0.5)
    async with st.lock:  # дождаться отложенных анонсов голосов
        pass

    out = tally(st.players, dict(st.votes))
    if out.totals:
        rows = sorted(out.totals.items(), key=lambda x: -x[1])
        lines = [("🚫 Пропуск" if t == 0 else f"№{st.players[t].seat} {st.players[t].name}") + f" — {w}" for t, w in rows]
        await _send(bot, st.chat_id, "📊 <b>Итоги голосования:</b>\n" + "\n".join(lines))

    if out.hanged is None:
        msg = {
            "none": "🤷 Никто не проголосовал — сегодня никого не повесили.",
            "tie": "⚖️ Голоса разделились — никого не повесили.",
            "skip": "🚫 Город решил никого не вешать.",
            "protected": "⚖️ Больше всех голосов набрал игрок, но повесить его не удалось.",
        }[out.reason]
        await _send(bot, st.chat_id, msg)
        return

    hp = st.players[out.hanged]
    deaths = [hp.uid]
    text = f"⚰️ По решению города повешен <b>{hp.name}</b> (№{hp.seat}) — {ROLE_NAMES[hp.role]}."
    if hp.role == R.SUICIDE:
        st.extra_winners.add(hp.uid)
        text += "\n🤦 Самоубийца добился своего — он побеждает!"
    await _send(bot, st.chat_id, text)
    if hp.role == R.KAMIKAZE:
        victim = await _kamikaze(bot, st, hp)
        vp = st.players.get(victim) if victim else None
        if vp and vp.alive and vp.role not in (R.KILLER, R.KAMIKAZE):
            deaths.append(vp.uid)
            await _send(bot, st.chat_id, f"💣 Камикадзе забрал с собой <b>{vp.name}</b> (№{vp.seat}) — {ROLE_NAMES[vp.role]}.")
        else:
            await _send(bot, st.chat_id, "💣 Камикадзе не смог никого забрать.")
    for uid, t in apply_outcome(st.players, deaths, []):
        await _send(bot, uid, t)


async def _kamikaze(bot: Bot, st: GameState, kz: P) -> int | None:
    items = [(p.uid, _label(p)) for p in st.alive() if p.uid != kz.uid]
    if not items:
        return None
    st.choices.clear(); st.choice_expected = {("kz", kz.uid)}; st.choice_event.clear()
    if not await _send(bot, kz.uid, "💣 Вас повесили! Кого заберёте с собой?", reply_markup=kamikaze_kb(st.game_id, items)):
        return None
    try:
        await asyncio.wait_for(st.choice_event.wait(), 25)
    except asyncio.TimeoutError:
        pass
    return st.choices.get(("kz", kz.uid))


# ───────── конец игры ─────────
async def _try_finish(bot: Bot, st: GameState) -> bool:
    w = check_win(st.players, st.extra_winners)
    if not w:
        return False
    st.phase = "finished"
    await _sync(st)
    text = final_text(w.title, list(st.players.values()), w.winners)
    if REWARD_PLAY or REWARD_WIN:
        text += f"\n\n💵 Награды: участие +{REWARD_PLAY}, победа +{REWARD_WIN}"
    await _send(bot, st.chat_id, text)
    async with SessionMaker() as session:
        game = await session.get(Game, st.game_id)
        await finish_game(session, game, w.team, w.winners)
    return True


async def finish_game(session: AsyncSession, game: Game, winner_team: Team | None, winners: set[int]) -> None:
    """Завершает игру и обновляет статистику игроков."""
    for gp, u in await get_players(session, game.id):
        gp.won = u.id in winners
        s = u.stats
        s.games_played += 1
        u.money += REWARD_PLAY + (REWARD_WIN if gp.won else 0)
        if gp.won:
            role = gp.original_role or gp.role
            team = Team.PEACE if role == R.WEREWOLF else ROLE_TEAM[role]
            s.wins_total += 1
            if team == Team.PEACE:
                s.wins_peace += 1
            elif team == Team.MAFIA:
                s.wins_mafia += 1
            else:
                s.wins_neutral += 1
    game.phase, game.winner_team, game.finished_at = GamePhase.FINISHED, winner_team, utcnow()
    await session.commit()
    manager.drop(game.chat_id)
