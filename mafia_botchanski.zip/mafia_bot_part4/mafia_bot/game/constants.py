from db.enums import ItemType, Role

MIN_PLAYERS = 5
MAX_PLAYERS = 30

ACTIVE_ROLES = {
    Role.COMMISSAR, Role.SERGEANT, Role.DOCTOR, Role.LOVER, Role.HOBO,
    Role.DON, Role.LAWYER, Role.KILLER, Role.JOURNALIST,
    Role.MANIAC, Role.ARSONIST, Role.SWINDLER, Role.SNITCH, Role.MAGE, Role.ALCHEMIST,
}
PASSIVE_PEACE = {Role.CITIZEN, Role.LUCKY, Role.KAMIKAZE, Role.SUICIDE, Role.MAYOR}

# Эти роли знают друг друга в личных сообщениях
MAFIA_TEAM_VISIBLE = {Role.DON, Role.MAFIA, Role.LAWYER}

# Предмет -> флаг в GamePlayer (предметы из инвентаря расходуются при старте игры)
ITEM_FLAGS = {
    ItemType.DOCUMENTS: "has_documents",
    ItemType.SHIELD: "has_shield",
    ItemType.MASK: "has_mask",
    ItemType.RIFLE: "has_rifle",
    ItemType.KILLER_SHIELD: "has_killer_shield",
    ItemType.VOTE_SHIELD: "has_vote_shield",
}

# Черновой порядок разрешения ночи (часть 3): блокировки → защиты → атаки → проверки → сбор информации
NIGHT_ORDER = [
    Role.LOVER, Role.SWINDLER, Role.LAWYER, Role.DOCTOR, Role.ALCHEMIST,
    Role.ARSONIST, Role.MANIAC, Role.DON, Role.KILLER, Role.COMMISSAR,
    Role.SERGEANT, Role.SNITCH, Role.MAGE, Role.HOBO, Role.JOURNALIST,
]

MAFIA_SIDE = {Role.DON, Role.MAFIA, Role.LAWYER, Role.KILLER, Role.JOURNALIST}
MAFIA_CHAT_ROLES = {Role.DON, Role.MAFIA}  # ночной чат команды

REGISTRATION_SECONDS = 120
NIGHT_SECONDS = 60
DAY_SECONDS = 60
VOTE_SECONDS = 45

# Награды в 💵 за игру (0 — отключить)
REWARD_PLAY = 20
REWARD_WIN = 50
