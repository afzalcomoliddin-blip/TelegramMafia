"""Разрешение ночи — чистая логика без БД и Telegram."""
import random
from dataclasses import dataclass, field

from db.enums import Role
from game.constants import MAFIA_TEAM_VISIBLE
from game.state import Action, P
from texts.roles import ROLE_NAMES

R = Role
KILLER_TARGETS = {R.HOBO, R.DOCTOR, R.LOVER, R.SERGEANT, R.KAMIKAZE, R.MANIAC, R.ARSONIST}
JOURNALIST_FINDS = {R.LOVER, R.DOCTOR, R.MANIAC, R.ARSONIST, R.HOBO}
ACTING_ROLES = {
    R.COMMISSAR, R.DOCTOR, R.LOVER, R.HOBO, R.DON, R.LAWYER, R.KILLER, R.JOURNALIST,
    R.MANIAC, R.ARSONIST, R.SWINDLER, R.SNITCH, R.ALCHEMIST,
}
# Что делает «случайное срабатывание способности» Алхимика
INJECT_KIND = {
    R.DOCTOR: "heal", R.LOVER: "block", R.HOBO: "visit", R.LAWYER: "protect", R.KILLER: "kill",
    R.MANIAC: "kill", R.JOURNALIST: "investigate", R.SWINDLER: "disguise", R.SNITCH: "snitch",
    R.ARSONIST: "mark",
}
_KIND = {
    R.DOCTOR: "heal", R.LOVER: "block", R.HOBO: "visit", R.DON: "kill", R.LAWYER: "protect",
    R.KILLER: "kill", R.JOURNALIST: "investigate", R.MANIAC: "kill", R.ARSONIST: "mark",
    R.SWINDLER: "disguise", R.SNITCH: "snitch", R.ALCHEMIST: "experiment",
}
_ATTACK_KIND = {R.DON: "don", R.MANIAC: "maniac", R.COMMISSAR: "commissar", R.KILLER: "killer"}


def action_kind(role: Role, mode: str | None = None) -> str | None:
    """mode для Комиссара: 'c' — проверить, 'k' — убить."""
    if role == R.COMMISSAR:
        return "kill" if mode == "k" else "check"
    return _KIND.get(role)


def allowed_targets(players: dict[int, P], p: P) -> list[int]:
    alive = [q for q in players.values() if q.alive]
    others = [q.uid for q in alive if q.uid != p.uid]
    r = p.role
    if r == R.DOCTOR:
        return [q.uid for q in alive if q.uid != p.uid or not p.self_heal_used]
    if r == R.LAWYER:
        t = [q.uid for q in alive if q.uid != p.uid and q.role in (R.MAFIA, R.DON, R.KILLER, R.JOURNALIST)]
        if not p.self_protect_used:
            t.append(p.uid)
        return t
    if r == R.DON:  # своих (Дон/Мафия/Адвокат) в списке нет
        return [q.uid for q in alive if q.role not in MAFIA_TEAM_VISIBLE]
    if r == R.MANIAC:  # нельзя бить одного и того же две ночи подряд
        return [u for u in others if u != p.last_target]
    if r == R.ARSONIST:
        return [u for u in others if u not in p.marks]
    return others


@dataclass
class Death:
    uid: int
    cause: str
    by: list[int] = field(default_factory=list)


@dataclass
class NightResult:
    deaths: dict[int, Death] = field(default_factory=dict)
    dms: dict[int, list[str]] = field(default_factory=dict)
    public: list[str] = field(default_factory=list)
    mage_prompts: list[tuple[int, int]] = field(default_factory=list)  # (маг, нападавший)
    transforms: list[tuple[int, Role]] = field(default_factory=list)
    silenced: set[int] = field(default_factory=set)
    winners: set[int] = field(default_factory=set)  # индивидуальные победы (Поджигатель)

    def dm(self, uid: int, text: str) -> None:
        self.dms.setdefault(uid, []).append(text)

    def kill(self, uid: int, cause: str, by: list[int] | None = None) -> None:
        d = self.deaths.setdefault(uid, Death(uid, cause, []))
        for b in by or []:
            if b not in d.by:
                d.by.append(b)


def resolve_night(players: dict[int, P], actions: dict[int, Action], rng: random.Random | None = None) -> NightResult:
    rng = rng or random.Random()
    res = NightResult()
    for p in players.values():
        p.protected = False
        p.disguise = None
    live = [p for p in players.values() if p.alive]
    acts: list[tuple[int, Action]] = [(u, a) for u, a in actions.items() if u in players and players[u].alive]
    disabled: set[int] = set()

    def ok(t) -> bool:
        return t is not None and t in players and players[t].alive

    # ── Алхимик ──
    for u, a in list(acts):
        if players[u].role != R.ALCHEMIST or a.kind != "experiment" or not ok(a.target):
            continue
        t = players[a.target]
        res.dm(u, "⚗️ Эксперимент проведён.")
        if t.role == R.DON:
            pool = [q.uid for q in live if q.uid != u]
            if pool:
                acts.append((u, Action("alch_kill", rng.choice(pool))))
        elif t.role == R.COMMISSAR:
            disabled.add(t.uid)
        elif t.role in INJECT_KIND:
            pool = [q.uid for q in live if q.uid != t.uid]
            if pool:
                acts.append((t.uid, Action(INJECT_KIND[t.role], rng.choice(pool), injected=True)))

    # ── Любовница ──
    blocked: dict[int, int] = {}
    for u, a in acts:
        if players[u].role == R.LOVER and a.kind == "block" and ok(a.target):
            t = players[a.target]
            if t.role == R.KILLER:  # Убийцу не остановить, уведомления нет
                continue
            blocked[t.uid] = u
            if t.role in (R.LAWYER, R.JOURNALIST):
                res.dm(t.uid, "💃 К вам приходила Любовница. Ночной выбор сохранён, но днём вы не сможете писать и голосовать.")
            else:
                res.dm(t.uid, "💃 К вам приходила Любовница — этой ночью вы не смогли сделать ход. Днём вы не сможете писать и голосовать.")

    def can_act(u: int) -> bool:
        r = players[u].role
        if r == R.COMMISSAR and u in disabled:
            return False
        return not (u in blocked and r not in (R.LAWYER, R.JOURNALIST))

    # ── Адвокат ──
    for u, a in acts:
        if players[u].role == R.LAWYER and a.kind == "protect" and ok(a.target) and can_act(u):
            players[a.target].protected = True
            if a.target == u and not a.injected:
                players[u].self_protect_used = True

    # ── Доктор ──
    healed: dict[int, int] = {}
    for u, a in acts:
        if players[u].role == R.DOCTOR and a.kind == "heal" and ok(a.target) and can_act(u):
            healed[a.target] = u
            if a.target == u and not a.injected:
                players[u].self_heal_used = True

    visits = [(u, a.target) for u, a in acts if ok(a.target) and a.kind != "experiment"]

    # ── Проверки Комиссара и Стукача ──
    checked: set[int] = set()
    for u, a in acts:
        if players[u].role == R.COMMISSAR and a.kind == "check" and ok(a.target) and can_act(u):
            t = players[a.target]
            checked.add(t.uid)
            shown = R.CITIZEN if (t.role == R.KILLER or t.protected or t.documents) else t.role
            res.dm(u, f"🔍 Результат проверки: <b>{t.name}</b> — {ROLE_NAMES[shown]}")
    for u, a in acts:
        if players[u].role == R.SNITCH and a.kind == "snitch" and ok(a.target) and can_act(u):
            t = players[a.target]
            res.dm(u, f"🤓 Вы проверили <b>{t.name}</b>.")
            if t.uid in checked:
                res.public.append(f"🤓 Стукач раскрыл: <b>{t.name}</b> — {ROLE_NAMES[t.role]}.")

    # ── Аферист, Поджигатель (метки) ──
    burners: list[int] = []
    for u, a in acts:
        r = players[u].role
        if r == R.SWINDLER and a.kind == "disguise" and ok(a.target) and can_act(u):
            players[u].disguise = a.target
            res.dm(u, f"🤹 Днём вы голосуете под именем <b>{players[a.target].name}</b>.")
        elif r == R.ARSONIST and a.kind == "mark" and ok(a.target) and a.target != u and can_act(u):
            players[u].marks.add(a.target)
            res.dm(u, f"🧟 Вы выбрали <b>{players[a.target].name}</b>. Отмечено игроков: {len(players[u].marks)}.")
        elif r == R.ARSONIST and a.kind == "burn_all" and can_act(u):
            burners.append(u)

    # ── Нападения ──
    attacks: list[tuple[int, int, str]] = []

    def add(att: int, vic, kind: str) -> None:
        if ok(vic) and vic != att:
            attacks.append((att, vic, kind))

    for u, a in acts:
        r = players[u].role
        if a.kind == "kill" and r in _ATTACK_KIND:
            if can_act(u):
                add(u, a.target, _ATTACK_KIND[r])
            elif r == R.MANIAC and ok(a.target) and players[a.target].role == R.MAGE:
                res.mage_prompts.append((a.target, u))  # попытка на Мага сохраняется даже под Любовницей
        elif a.kind == "alch_kill" and can_act(u):
            add(u, a.target, "alch")
    for u in burners:
        for m in players[u].marks:
            add(u, m, "burn")
        res.kill(u, "burn_self", [u])

    by_victim: dict[int, list[tuple[int, str]]] = {}
    for att, vic, kind in attacks:
        by_victim.setdefault(vic, []).append((att, kind))
    attackers_of: dict[int, list[tuple[int, str]]] = {}

    for vic, atks in by_victim.items():
        vp = players[vic]
        valid = []
        for att, kind in atks:
            if kind in ("don", "commissar", "burn") and vp.role == R.KILLER:
                continue  # Убийцу не убить Доном/Комиссаром и не поджечь
            if kind == "don" and vp.role in (R.DON, R.MAFIA, R.LAWYER):
                continue
            valid.append((att, kind))
        if vp.role == R.MAGE:  # попытка тщетна — Маг выбирает судьбу нападавшего
            th = [x for x in valid if x[1] in ("don", "maniac", "commissar")]
            for att, _ in th:
                res.mage_prompts.append((vic, att))
            valid = [x for x in valid if x not in th]
        killer_hits = [x for x in valid if x[1] == "killer"]
        normal = [x for x in valid if x[1] != "killer"]
        dead_by: list[tuple[int, str]] = []

        for att, _ in killer_hits:
            if vp.role == R.COMMISSAR:
                res.kill(att, "killer_suicide", [vic])
                res.dm(att, "🕴 Вы попытались убить Комиссара и погибли.")
            elif vp.role not in KILLER_TARGETS:
                res.dm(att, "🕴 Цель оказалась не из ваших врагов — убийство не удалось.")
            elif vp.killer_shield:
                vp.killer_shield = False
                res.dm(vic, "⛑ Защита от Убийцы спасла вас (она израсходована).")
                res.dm(att, "🕴 Убийство не удалось.")
            else:
                dead_by.append((att, "killer"))

        if normal:
            if vic in healed:  # лечение гасит всех, кроме Убийцы
                doc = healed[vic]
                res.dm(doc, f"💉 Вы спасли <b>{vp.name}</b>.")
                if vp.role == R.WEREWOLF and any(k in ("don", "commissar") for _, k in normal):
                    res.dm(doc, f"🐺 <b>{vp.name}</b> — Оборотень!")
                res.dm(vic, "💉 Вас пытались убить, но Доктор спас вас.")
                normal = []
            else:
                if vp.shield and any(not players[a].rifle for a, _ in normal):
                    vp.shield = False  # защита срабатывает против всех сразу; винтовка её игнорирует
                    normal = [(a, k) for a, k in normal if players[a].rifle]
                    res.dm(vic, "🛡 Вас пытались убить, но защита спасла вас (она израсходована).")
                if normal and vp.role == R.LUCKY and any(k in ("don", "maniac") for _, k in normal) and rng.random() < 0.5:
                    normal = [(a, k) for a, k in normal if k not in ("don", "maniac")]  # без уведомления
        dead_by += normal
        if not dead_by:
            continue
        kinds = {k for _, k in dead_by}
        if vp.role == R.WEREWOLF:
            if kinds & {"maniac", "killer", "burn", "alch"} or {"don", "commissar"} <= kinds:
                pass  # погибает
            elif "don" in kinds:
                res.transforms.append((vic, R.MAFIA))
                res.dm(vic, "🐺 На вас напала Мафия — вы выжили и становитесь Мафией!")
                continue
            else:
                res.transforms.append((vic, R.SERGEANT))
                res.dm(vic, "🐺 Вас пытался убить Комиссар — вы выжили и становитесь Сержантом!")
                continue
        res.kill(vic, dead_by[0][1], [a for a, _ in dead_by])
        attackers_of[vic] = dead_by
        if vp.role == R.KAMIKAZE:
            for att, k in dead_by:
                if k in ("don", "maniac"):
                    res.kill(att, "kamikaze", [vic])

    for u in burners:
        n = sum(1 for lst in attackers_of.values() if any(a == u and k == "burn" for a, k in lst))
        players[u].marks.clear()
        if n >= 3:
            res.winners.add(u)

    # ── Бомж ──
    for u, a in acts:
        if players[u].role == R.HOBO and a.kind == "visit" and ok(a.target) and can_act(u):
            t = players[a.target]
            if t.uid in res.deaths:
                seen = [x for x in attackers_of.get(t.uid, [])
                        if players[x[0]].role in (R.DON, R.COMMISSAR, R.MANIAC) and not players[x[0]].mask]
                if seen:
                    for att, _ in seen:
                        res.dm(u, f"🧙 Пока вы брали бутылку у <b>{t.name}</b>, вы видели: {ROLE_NAMES[players[att].role]} <b>{players[att].name}</b>.")
                else:
                    res.dm(u, f"🧙 Вы взяли бутылку у <b>{t.name}</b>, но убийцу не разглядели.")
            else:
                res.dm(u, f"🧙 Вы зашли к <b>{t.name}</b> за бутылкой — ничего не произошло.")

    # ── Журналист ──
    for u, a in acts:
        if players[u].role == R.JOURNALIST and a.kind == "investigate" and ok(a.target) and a.target != u:
            t = players[a.target]
            found = t.role in JOURNALIST_FINDS and not t.mask
            guests: list[str] = []
            if t.role not in (R.COMMISSAR, R.KILLER):  # гостей Комиссара и Убийцы не видно
                guests = [players[x].name for x, y in visits
                          if y == t.uid and x != u and players[x].role not in (R.COMMISSAR, R.KILLER)]
            if found:
                res.public.append(f"📰 Журналист выяснил: <b>{t.name}</b> — {ROLE_NAMES[t.role]}.")
            if guests:
                res.public.append(f"📰 Журналист видел: к <b>{t.name}</b> ночью приходили — {', '.join(dict.fromkeys(guests))}.")
            if not found and not guests:
                res.dm(u, "📰 Ничего интересного обнаружить не удалось.")

    # ── Молчание днём ──
    res.silenced = set(blocked)
    for t, lover in blocked.items():  # Дон, пытавшийся убить посетившую его Любовницу, может писать и голосовать
        if players[t].role == R.DON:
            act = actions.get(t)
            if act and act.kind == "kill" and act.target == lover:
                res.silenced.discard(t)
    return res


def apply_outcome(players: dict[int, P], deaths, transforms, rng: random.Random | None = None) -> list[tuple[int, str]]:
    """Применяет смерти и превращения, передаёт места Дона и Комиссара. Возвращает личные уведомления."""
    rng = rng or random.Random()
    notes: list[tuple[int, str]] = []
    deaths = list(deaths)
    for uid, role in transforms:
        if uid not in deaths and players[uid].alive:
            players[uid].role = role
    dead_roles = {players[u].role for u in deaths}
    for u in deaths:
        players[u].alive = False
    for dead, heir_from, heir_to, text in (
        (R.DON, R.MAFIA, R.DON, "🤵 Дон погиб — теперь вы Дон!"),
        (R.COMMISSAR, R.SERGEANT, R.COMMISSAR, "🕵️ Комиссар погиб — теперь вы Комиссар Каттани!"),
    ):
        if dead in dead_roles and not any(p.alive and p.role == dead for p in players.values()):
            heirs = [p for p in players.values() if p.alive and p.role == heir_from]
            if heirs:
                h = rng.choice(heirs)
                h.role = heir_to
                notes.append((h.uid, text))
    return notes
