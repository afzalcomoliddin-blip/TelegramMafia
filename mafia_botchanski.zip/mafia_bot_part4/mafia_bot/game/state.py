from __future__ import annotations

import asyncio
from dataclasses import dataclass, field

from db.enums import Role


@dataclass
class Action:
    kind: str
    target: int | None = None
    injected: bool = False  # действие, вызванное экспериментом Алхимика


@dataclass
class P:
    """Игрок в рантайме."""
    uid: int
    seat: int
    name: str            # HTML-безопасное имя
    raw: str             # обычное имя (кнопки)
    username: str | None
    role: Role
    orig_role: Role
    gp_id: int
    alive: bool = True
    documents: bool = False
    shield: bool = False
    mask: bool = False
    rifle: bool = False
    killer_shield: bool = False
    vote_shield: bool = False
    self_heal_used: bool = False
    self_protect_used: bool = False
    last_target: int | None = None
    marks: set[int] = field(default_factory=set)  # Поджигатель
    disguise: int | None = None                   # Аферист: чьё имя использует днём
    protected: bool = False                       # защита Адвоката


@dataclass
class GameState:
    game_id: int
    chat_id: int
    players: dict[int, P]
    bot_username: str = ""
    night_seconds: int = 60
    day_seconds: int = 60
    vote_seconds: int = 45
    phase: str = "night"  # night | resolve | day | vote | finished
    day: int = 1
    actions: dict[int, Action] = field(default_factory=dict)
    modes: dict[int, str] = field(default_factory=dict)
    expected: set[int] = field(default_factory=set)
    prompt_msgs: dict[int, int] = field(default_factory=dict)
    night_event: asyncio.Event = field(default_factory=asyncio.Event)
    votes: dict[int, int] = field(default_factory=dict)
    eligible: set[int] = field(default_factory=set)
    vote_event: asyncio.Event = field(default_factory=asyncio.Event)
    silenced: set[int] = field(default_factory=set)
    extra_winners: set[int] = field(default_factory=set)
    choices: dict = field(default_factory=dict)
    choice_expected: set = field(default_factory=set)
    choice_event: asyncio.Event = field(default_factory=asyncio.Event)
    lock: asyncio.Lock = field(default_factory=asyncio.Lock)

    def alive(self) -> list[P]:
        return [p for p in self.players.values() if p.alive]
