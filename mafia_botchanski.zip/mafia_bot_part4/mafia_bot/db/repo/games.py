from sqlalchemy import func, select, update
from sqlalchemy.ext.asyncio import AsyncSession

from db.enums import GamePhase
from db.models import ChatSettings, Game, GamePlayer, User
from game.constants import MAX_PLAYERS
from utils import utcnow


async def get_chat_settings(session: AsyncSession, chat_id: int, title: str | None = None) -> ChatSettings:
    cs = await session.get(ChatSettings, chat_id)
    if cs is None:
        cs = ChatSettings(chat_id=chat_id, title=title)
        session.add(cs)
        await session.commit()
    elif title and cs.title != title:
        cs.title = title
        await session.commit()
    return cs


async def get_active_game(session: AsyncSession, chat_id: int) -> Game | None:
    res = await session.execute(
        select(Game).where(Game.chat_id == chat_id, Game.phase != GamePhase.FINISHED)
        .order_by(Game.id.desc()).limit(1)
    )
    return res.scalar_one_or_none()


async def list_active_games(session: AsyncSession) -> list[tuple[Game, ChatSettings | None]]:
    res = await session.execute(
        select(Game, ChatSettings)
        .outerjoin(ChatSettings, ChatSettings.chat_id == Game.chat_id)
        .where(Game.phase != GamePhase.FINISHED).order_by(Game.id)
    )
    return [(g, c) for g, c in res.all()]


async def get_players(session: AsyncSession, game_id: int) -> list[tuple[GamePlayer, User]]:
    res = await session.execute(
        select(GamePlayer, User).join(User, User.id == GamePlayer.user_id)
        .where(GamePlayer.game_id == game_id).order_by(GamePlayer.seat, GamePlayer.id)
    )
    return [(gp, u) for gp, u in res.all()]


async def user_active_game(session: AsyncSession, user_id: int) -> Game | None:
    res = await session.execute(
        select(Game).join(GamePlayer, GamePlayer.game_id == Game.id)
        .where(GamePlayer.user_id == user_id, Game.phase != GamePhase.FINISHED).limit(1)
    )
    return res.scalar_one_or_none()


async def join_game(session: AsyncSession, game: Game, user: User) -> str:
    """ok | closed | full | already | busy"""
    if game.phase != GamePhase.REGISTRATION:
        return "closed"
    count = (await session.execute(
        select(func.count()).select_from(GamePlayer).where(GamePlayer.game_id == game.id)
    )).scalar_one()
    exists = (await session.execute(
        select(GamePlayer.id).where(GamePlayer.game_id == game.id, GamePlayer.user_id == user.id)
    )).first()
    if exists:
        return "already"
    busy = await user_active_game(session, user.id)
    if busy and busy.id != game.id:
        return "busy"
    if count >= MAX_PLAYERS:
        return "full"
    top = (await session.execute(
        select(func.max(GamePlayer.seat)).where(GamePlayer.game_id == game.id)
    )).scalar_one()
    session.add(GamePlayer(game_id=game.id, user_id=user.id, seat=(top or 0) + 1))
    await session.commit()
    return "ok"


async def leave_game(session: AsyncSession, game: Game, user_id: int) -> bool:
    if game.phase != GamePhase.REGISTRATION:
        return False
    res = await session.execute(
        select(GamePlayer).where(GamePlayer.game_id == game.id, GamePlayer.user_id == user_id)
    )
    gp = res.scalar_one_or_none()
    if not gp:
        return False
    await session.delete(gp)
    await session.commit()
    await renumber_seats(session, game.id)
    return True


async def close_stale_games(session: AsyncSession) -> int:
    """Рантайм-состояние не переживает перезапуск — незавершённые игры закрываем."""
    res = await session.execute(
        update(Game).where(Game.phase != GamePhase.FINISHED)
        .values(phase=GamePhase.FINISHED, finished_at=utcnow())
    )
    await session.commit()
    return res.rowcount or 0


async def renumber_seats(session: AsyncSession, game_id: int) -> None:
    """Номера 1..N по порядку входа (без пропусков)."""
    res = await session.execute(
        select(GamePlayer).where(GamePlayer.game_id == game_id).order_by(GamePlayer.id)
    )
    for i, gp in enumerate(res.scalars(), 1):
        gp.seat = i
    await session.commit()


async def get_seat(session: AsyncSession, game_id: int, user_id: int) -> int | None:
    return (await session.execute(
        select(GamePlayer.seat).where(GamePlayer.game_id == game_id, GamePlayer.user_id == user_id)
    )).scalar_one_or_none()
