from aiogram.types import User as TgUser
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from config import OWNER_ID
from db.models import AdminLevel, ItemType, Role, User, UserItem, UserStats


async def get_or_create_user(session: AsyncSession, tg: TgUser) -> User:
    user = await session.get(User, tg.id)
    is_new = user is None
    if is_new:
        user = User(id=tg.id, username=tg.username, full_name=tg.full_name)
        user.stats = UserStats()
        session.add(user)
    else:
        user.username = tg.username
        user.full_name = tg.full_name
    if user.id == OWNER_ID:
        user.admin_level = AdminLevel.OWNER
    await session.commit()
    if is_new:
        await session.refresh(user)  # подгружает stats/items (selectin)
    return user


async def get_items(session: AsyncSession, user_id: int) -> list[UserItem]:
    res = await session.execute(select(UserItem).where(UserItem.user_id == user_id))
    return list(res.scalars())


async def add_item(
    session: AsyncSession, user_id: int, item: ItemType, role: Role | None = None, amount: int = 1
) -> None:
    res = await session.execute(
        select(UserItem).where(
            UserItem.user_id == user_id, UserItem.item == item, UserItem.role == role
        )
    )
    row = res.scalar_one_or_none()
    if row:
        row.amount += amount
    else:
        session.add(UserItem(user_id=user_id, item=item, role=role, amount=amount))


async def find_user(session: AsyncSession, key: str) -> User | None:
    """Поиск по id или @username (пользователь должен был писать боту)."""
    if key.lstrip("-").isdigit():
        return await session.get(User, int(key))
    if key.startswith("@"):
        res = await session.execute(
            select(User).where(func.lower(User.username) == key[1:].lower())
        )
        return res.scalar_one_or_none()
    return None
