import enum


# ───────────── Enums ─────────────
class AdminLevel(enum.IntEnum):
    NONE = 0
    MODERATOR = 1
    JUNIOR = 2
    ADMIN = 3
    SENIOR = 4
    COOWNER = 5
    OWNER = 6


class Team(str, enum.Enum):
    PEACE = "peace"
    MAFIA = "mafia"
    NEUTRAL = "neutral"


class Role(str, enum.Enum):
    # мирные
    COMMISSAR = "commissar"
    SERGEANT = "sergeant"
    DOCTOR = "doctor"
    LOVER = "lover"
    HOBO = "hobo"
    CITIZEN = "citizen"
    LUCKY = "lucky"
    KAMIKAZE = "kamikaze"
    SUICIDE = "suicide"
    MAYOR = "mayor"
    # мафия
    DON = "don"
    MAFIA = "mafia"
    LAWYER = "lawyer"
    KILLER = "killer"
    JOURNALIST = "journalist"
    # нейтралы
    MANIAC = "maniac"
    ARSONIST = "arsonist"
    SWINDLER = "swindler"
    SNITCH = "snitch"
    MAGE = "mage"
    WEREWOLF = "werewolf"
    ALCHEMIST = "alchemist"


class ItemType(str, enum.Enum):
    DOCUMENTS = "documents"        # 190 💵
    SHIELD = "shield"              # 140 💵
    MASK = "mask"                  # 1 💎
    RIFLE = "rifle"                # 1 💎
    KILLER_SHIELD = "killer_shield"  # 2 💎
    VOTE_SHIELD = "vote_shield"    # 1 💎
    ACTIVE_ROLE = "active_role"    # 1 💎


class GamePhase(str, enum.Enum):
    REGISTRATION = "registration"
    NIGHT = "night"
    DAY = "day"
    VOTING = "voting"
    FINISHED = "finished"


class ActionType(str, enum.Enum):
    KILL = "kill"
    CHECK = "check"
    HEAL = "heal"
    VISIT = "visit"
    PROTECT = "protect"
    IGNITE = "ignite"
    EXPERIMENT = "experiment"
    MAGE_CHOICE = "mage_choice"
    SERGEANT_WATCH = "sergeant_watch"
