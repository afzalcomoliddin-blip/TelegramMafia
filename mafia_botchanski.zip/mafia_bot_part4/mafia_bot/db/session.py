from sqlalchemy import inspect, text
from sqlalchemy.ext.asyncio import async_sessionmaker, create_async_engine

from config import DATABASE_URL
from db.models import Base, BotSettings

engine = create_async_engine(DATABASE_URL, echo=False)
SessionMaker = async_sessionmaker(engine, expire_on_commit=False)


def _migrate(sync_conn) -> None:
    """Мини-миграции для баз, созданных предыдущими версиями."""
    cols = {c["name"] for c in inspect(sync_conn).get_columns("game_players")}
    if "seat" not in cols:
        sync_conn.execute(text("ALTER TABLE game_players ADD COLUMN seat INTEGER"))
    sync_conn.execute(text("UPDATE chat_settings SET day_seconds = 60 WHERE day_seconds = 90"))


async def init_db() -> None:
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
        await conn.run_sync(_migrate)
    async with SessionMaker() as session:
        if await session.get(BotSettings, 1) is None:
            session.add(BotSettings(id=1))
            await session.commit()
