from __future__ import annotations

import enum
from datetime import datetime

from sqlalchemy import (
    BigInteger, Boolean, DateTime, Enum, ForeignKey, Integer, String, Text,
    UniqueConstraint, func,
)
from sqlalchemy.ext.asyncio import AsyncAttrs
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship

from config import OWNER_ID  # noqa: F401  (единственный источник — config.py)


class Base(AsyncAttrs, DeclarativeBase):
    pass


from db.enums import (  # noqa: F401,E402
    ActionType, AdminLevel, GamePhase, ItemType, Role, Team,
)


# ───────────── Пользователи ─────────────
class User(Base):
    __tablename__ = "users"

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True)  # Telegram ID
    username: Mapped[str | None] = mapped_column(String(64), index=True)
    full_name: Mapped[str] = mapped_column(String(128))
    money: Mapped[int] = mapped_column(Integer, default=0)      # 💵
    diamonds: Mapped[int] = mapped_column(Integer, default=0)   # 💎
    admin_level: Mapped[AdminLevel] = mapped_column(Enum(AdminLevel), default=AdminLevel.NONE)
    is_banned: Mapped[bool] = mapped_column(Boolean, default=False)
    ban_reason: Mapped[str | None] = mapped_column(Text)
    muted_until: Mapped[datetime | None] = mapped_column(DateTime)
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())

    stats: Mapped[UserStats] = relationship(back_populates="user", uselist=False, lazy="selectin")
    items: Mapped[list[UserItem]] = relationship(back_populates="user", lazy="selectin")


class UserStats(Base):
    __tablename__ = "user_stats"

    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), primary_key=True)
    games_played: Mapped[int] = mapped_column(Integer, default=0)
    wins_total: Mapped[int] = mapped_column(Integer, default=0)
    wins_peace: Mapped[int] = mapped_column(Integer, default=0)
    wins_mafia: Mapped[int] = mapped_column(Integer, default=0)
    wins_neutral: Mapped[int] = mapped_column(Integer, default=0)

    user: Mapped[User] = relationship(back_populates="stats")


class UserItem(Base):
    __tablename__ = "user_items"
    __table_args__ = (UniqueConstraint("user_id", "item", "role"),)

    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), index=True)
    item: Mapped[ItemType] = mapped_column(Enum(ItemType))
    role: Mapped[Role | None] = mapped_column(Enum(Role))  # для ACTIVE_ROLE: какая роль куплена
    amount: Mapped[int] = mapped_column(Integer, default=1)

    user: Mapped[User] = relationship(back_populates="items")


# ───────────── Модерация ─────────────
class Warn(Base):
    __tablename__ = "warns"

    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), index=True)
    admin_id: Mapped[int] = mapped_column(BigInteger)
    reason: Mapped[str] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())
    expires_at: Mapped[datetime] = mapped_column(DateTime)  # created_at + 7 дней
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)


class Mute(Base):
    __tablename__ = "mutes"

    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int] = mapped_column(BigInteger, index=True)
    chat_id: Mapped[int] = mapped_column(BigInteger)
    admin_id: Mapped[int] = mapped_column(BigInteger)
    reason: Mapped[str] = mapped_column(Text)
    until: Mapped[datetime] = mapped_column(DateTime)
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())


class AdminLog(Base):
    __tablename__ = "admin_logs"

    id: Mapped[int] = mapped_column(primary_key=True)
    admin_id: Mapped[int] = mapped_column(BigInteger, index=True)
    action: Mapped[str] = mapped_column(String(64))
    target_id: Mapped[int | None] = mapped_column(BigInteger)
    details: Mapped[str | None] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())


class BotSettings(Base):
    """Глобальные флаги: /forceactive и т.п. (одна строка, id=1)."""
    __tablename__ = "bot_settings"

    id: Mapped[int] = mapped_column(primary_key=True, default=1)
    force_active: Mapped[bool] = mapped_column(Boolean, default=False)


# ───────────── Игра ─────────────
class Game(Base):
    __tablename__ = "games"

    id: Mapped[int] = mapped_column(primary_key=True)
    chat_id: Mapped[int] = mapped_column(BigInteger, index=True)
    creator_id: Mapped[int] = mapped_column(BigInteger)
    phase: Mapped[GamePhase] = mapped_column(Enum(GamePhase), default=GamePhase.REGISTRATION)
    day_number: Mapped[int] = mapped_column(Integer, default=0)
    only_active: Mapped[bool] = mapped_column(Boolean, default=False)  # /onlyactive
    winner_team: Mapped[Team | None] = mapped_column(Enum(Team))
    started_at: Mapped[datetime | None] = mapped_column(DateTime)
    finished_at: Mapped[datetime | None] = mapped_column(DateTime)

    players: Mapped[list[GamePlayer]] = relationship(back_populates="game", lazy="selectin")


class GamePlayer(Base):
    __tablename__ = "game_players"
    __table_args__ = (UniqueConstraint("game_id", "user_id"),)

    id: Mapped[int] = mapped_column(primary_key=True)
    game_id: Mapped[int] = mapped_column(ForeignKey("games.id"), index=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"))
    role: Mapped[Role | None] = mapped_column(Enum(Role))
    original_role: Mapped[Role | None] = mapped_column(Enum(Role))  # для Оборотня / Сержанта
    is_alive: Mapped[bool] = mapped_column(Boolean, default=True)
    seat: Mapped[int | None] = mapped_column(Integer)  # постоянный номер игрока в игре (1..30)
    won: Mapped[bool | None] = mapped_column(Boolean)

    # флаги способностей и предметов
    self_heal_used: Mapped[bool] = mapped_column(Boolean, default=False)     # Доктор
    self_protect_used: Mapped[bool] = mapped_column(Boolean, default=False)  # Адвокат
    has_documents: Mapped[bool] = mapped_column(Boolean, default=False)
    has_shield: Mapped[bool] = mapped_column(Boolean, default=False)
    has_mask: Mapped[bool] = mapped_column(Boolean, default=False)
    has_rifle: Mapped[bool] = mapped_column(Boolean, default=False)
    has_killer_shield: Mapped[bool] = mapped_column(Boolean, default=False)
    has_vote_shield: Mapped[bool] = mapped_column(Boolean, default=False)
    is_revealed: Mapped[bool] = mapped_column(Boolean, default=False)  # роль раскрыта
    last_target_id: Mapped[int | None] = mapped_column(BigInteger)     # Маньяк: не бить 2 ночи подряд
    ignited_count: Mapped[int] = mapped_column(Integer, default=0)     # Поджигатель
    swindler_name_of: Mapped[int | None] = mapped_column(BigInteger)   # Аферист: чьё имя использует

    game: Mapped[Game] = relationship(back_populates="players")


class NightAction(Base):
    __tablename__ = "night_actions"

    id: Mapped[int] = mapped_column(primary_key=True)
    game_id: Mapped[int] = mapped_column(ForeignKey("games.id"), index=True)
    night: Mapped[int] = mapped_column(Integer)
    actor_id: Mapped[int] = mapped_column(BigInteger)
    target_id: Mapped[int | None] = mapped_column(BigInteger)
    action: Mapped[ActionType] = mapped_column(Enum(ActionType))
    payload: Mapped[str | None] = mapped_column(String(64))


class Vote(Base):
    __tablename__ = "votes"
    __table_args__ = (UniqueConstraint("game_id", "day", "voter_id"),)

    id: Mapped[int] = mapped_column(primary_key=True)
    game_id: Mapped[int] = mapped_column(ForeignKey("games.id"), index=True)
    day: Mapped[int] = mapped_column(Integer)
    voter_id: Mapped[int] = mapped_column(BigInteger)
    target_id: Mapped[int] = mapped_column(BigInteger)
    weight: Mapped[int] = mapped_column(Integer, default=1)  # Мэр = 2


class RolePurchase(Base):
    """Предзаказ активной роли на следующую игру (за 💎)."""
    __tablename__ = "role_purchases"

    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), index=True)
    role: Mapped[Role] = mapped_column(Enum(Role))
    chat_id: Mapped[int] = mapped_column(BigInteger)
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())


class ChatSettings(Base):
    """Известные групповые чаты и их игровые настройки (таймеры в секундах)."""
    __tablename__ = "chat_settings"

    chat_id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    title: Mapped[str | None] = mapped_column(String(256))
    registration_seconds: Mapped[int] = mapped_column(Integer, default=120)
    night_seconds: Mapped[int] = mapped_column(Integer, default=60)
    day_seconds: Mapped[int] = mapped_column(Integer, default=60)
    vote_seconds: Mapped[int] = mapped_column(Integer, default=45)
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())
