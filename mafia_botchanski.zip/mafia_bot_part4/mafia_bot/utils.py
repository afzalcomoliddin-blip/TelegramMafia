from datetime import datetime, timezone


def utcnow() -> datetime:
    """Naive UTC — так хранятся все даты в БД."""
    return datetime.now(timezone.utc).replace(tzinfo=None)
