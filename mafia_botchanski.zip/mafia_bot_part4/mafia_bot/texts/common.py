from html import escape

from db.models import User


def mention(u: User) -> str:
    return f'<a href="tg://user?id={u.id}">{escape(u.full_name)}</a>'


def fmt_user(u: User) -> str:
    return f"{mention(u)} (<code>{u.id}</code>)"
