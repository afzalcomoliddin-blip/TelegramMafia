from collections import Counter

from db.enums import Role
from db.models import Game, GamePlayer, User
from game.constants import ITEM_FLAGS, MAX_PLAYERS, MIN_PLAYERS
from services.shop import CATALOG
from texts.common import mention
from texts.role_info import ROLE_BRIEF, TEAM_NAMES
from texts.roles import ROLE_NAMES, ROLE_TEAM

Rows = list[tuple[GamePlayer, User]]


def reg_text(game: Game, rows: Rows, seconds: int) -> str:
    lines = ["🎭 <b>Начинается игра в мафию</b>", ""]
    if game.only_active:
        lines.append("🎯 Режим: только активные роли")
    lines += [
        f"👥 Игроков: <b>{len(rows)}/{MAX_PLAYERS}</b> (минимум {MIN_PLAYERS})",
        f"⏳ Старт через {seconds // 60} мин., если наберётся {MIN_PLAYERS}+ игроков, иначе игра отменится",
        "",
    ]
    if rows:
        lines += [f"{gp.seat or i}. {mention(u)}" for i, (gp, u) in enumerate(rows, 1)]
    else:
        lines.append("<i>Пока никого. Нажмите «Войти в игру» 👇</i>")
    return "\n".join(lines)


def role_message(gp: GamePlayer, mates: Rows) -> str:
    role = gp.role
    text = (
        f"🎭 <b>Ваша роль: {ROLE_NAMES[role]}</b>\n"
        f"🔢 Ваш номер: <b>№{gp.seat}</b>\n"
        f"{TEAM_NAMES[ROLE_TEAM[role]]}\n\n{ROLE_BRIEF[role]}"
    )
    if mates:
        text += "\n\n🤝 <b>Ваша команда:</b>\n" + "\n".join(
            f"• №{g.seat} {mention(u)} — {ROLE_NAMES[g.role]}" for g, u in mates
        )
    items = [f"{CATALOG[it].emoji} {CATALOG[it].name}" for it, flag in ITEM_FLAGS.items() if getattr(gp, flag)]
    if items:
        text += "\n\n🎒 <b>Ваши предметы:</b> " + ", ".join(items)
    text += "\n\nℹ️ Ночью бот пришлёт кнопки действий, голосуете тоже здесь, в личных сообщениях."
    return text


def composition_text(rows: Rows) -> str:
    from db.enums import Team
    cnt = Counter(ROLE_TEAM[gp.role] for gp, _ in rows)
    names = "\n".join(f"{gp.seat}. {mention(u)}" for gp, u in rows)
    return (
        "🎲 <b>Роли розданы!</b> Проверьте личные сообщения от бота.\n\n"
        f"🕊 Мирных: <b>{cnt[Team.PEACE]}</b>\n"
        f"🤵 Мафии: <b>{cnt[Team.MAFIA]}</b>\n"
        f"🔪 Нейтральных: <b>{cnt[Team.NEUTRAL]}</b>\n\n"
        f"👥 <b>Игроки:</b>\n{names}"
    )


def _roles_line(roles) -> str:
    cnt = Counter(roles)
    return ", ".join(ROLE_NAMES[r] + (f" ×{cnt[r]}" if cnt[r] > 1 else "") for r in Role if cnt.get(r))


def night_report_text(acted: list[Role], missed: int) -> str:
    text = "📋 <b>Ночной отчёт</b>\n" + (f"Ходили: {_roles_line(acted)}" if acted else "Ночью никто не ходил.")
    if missed:
        text += f"\nНе успели сделать ход: {missed} чел."
    return text


def deaths_text(items: list[tuple[str, Role, list[Role], str]]) -> str:
    head = "🌙 <b>Ночь закончилась...</b>"
    if not items:
        return head + "\n\n🕊 Ночь прошла спокойно."
    blocks = []
    for name, role, killers, cause in items:
        b = [f"На улице нашли тело <b>{name}</b>.", f"Он оказался <b>{ROLE_NAMES[role]}</b>."]
        uniq = list(dict.fromkeys(killers))
        if cause == "burn_self":
            b.append("Он сгорел в собственном огне.")
        elif uniq:
            who = " и ".join(f"<b>{ROLE_NAMES[r]}</b>" for r in uniq)
            b.append(f"Его {'убили' if len(uniq) > 1 else 'убил'} {who}.")
        blocks.append("\n".join(b))
    return head + "\n\n" + "\n\n".join(blocks)


def alive_text(players, seconds: int) -> str:
    lines = ["☀️ <b>Живые игроки:</b>", ""]
    lines += [f"{p.seat}. {p.name}" for p in players]
    lines += [
        "", "Кто-то из них:", _roles_line(p.role for p in players),
        "", f"Всего: <b>{len(players)}</b> чел.", "",
        "Сейчас самое время обсудить результаты ночи...",
        f"⏳ Обсуждение: {seconds} сек.",
    ]
    return "\n".join(lines)


def final_text(title: str, players, winners: set[int]) -> str:
    lines = ["🏁 <b>Игра окончена!</b>", "", f"<b>{title}</b>", "", "📋 <b>Итоги:</b>"]
    for p in players:
        mark = "✅" if p.uid in winners else ("💀" if not p.alive else "▫️")
        lines.append(f"{mark} {p.seat}. {p.name} — {ROLE_NAMES[p.role]}")
    return "\n".join(lines)
