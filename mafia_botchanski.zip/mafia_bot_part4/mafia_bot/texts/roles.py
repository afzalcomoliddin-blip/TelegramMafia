from db.enums import Role, Team

ROLE_NAMES: dict[Role, str] = {
    Role.COMMISSAR: "🕵️ Комиссар Каттани",
    Role.SERGEANT: "👮 Сержант",
    Role.DOCTOR: "👨‍⚕️ Доктор",
    Role.LOVER: "💃 Любовница",
    Role.HOBO: "🧙 Бомж",
    Role.CITIZEN: "👨 Мирный житель",
    Role.LUCKY: "🤞 Счастливчик",
    Role.KAMIKAZE: "💣 Камикадзе",
    Role.SUICIDE: "🤦 Самоубийца",
    Role.MAYOR: "🎖 Мэр",
    Role.DON: "🤵 Дон",
    Role.MAFIA: "🤵 Мафия",
    Role.LAWYER: "🧑‍💼 Адвокат",
    Role.KILLER: "🕴️ Убийца",
    Role.JOURNALIST: "👩‍💻 Журналист",
    Role.MANIAC: "🔪 Маньяк",
    Role.ARSONIST: "🧟 Поджигатель",
    Role.SWINDLER: "🤹 Аферист",
    Role.SNITCH: "🤓 Стукач",
    Role.MAGE: "🧙‍♂️ Маг",
    Role.WEREWOLF: "🐺 Оборотень",
    Role.ALCHEMIST: "⚗️ Алхимик",
}

_PEACE = {Role.COMMISSAR, Role.SERGEANT, Role.DOCTOR, Role.LOVER, Role.HOBO,
          Role.CITIZEN, Role.LUCKY, Role.KAMIKAZE, Role.SUICIDE, Role.MAYOR}
_MAFIA = {Role.DON, Role.MAFIA, Role.LAWYER, Role.KILLER, Role.JOURNALIST}

ROLE_TEAM: dict[Role, Team] = {
    r: Team.PEACE if r in _PEACE else Team.MAFIA if r in _MAFIA else Team.NEUTRAL
    for r in Role
}
