from html import escape

from db.models import ItemType, User, UserItem
from services.permissions import LEVEL_NAMES, effective_level
from services.shop import CATALOG, currency_sign
from texts.roles import ROLE_NAMES


def start_text(name: str) -> str:
    return (
        f"🎭 <b>Добро пожаловать, {escape(name)}!</b>\n\n"
        "Это бот для игры в <b>«Русскую Мафию»</b> 🌃\n"
        "Город засыпает — просыпается мафия. Кто окажется хитрее?\n\n"
        "🕵️ Мирные ищут преступников\n"
        "🤵 Мафия уничтожает город\n"
        "🔪 Нейтралы играют сами за себя\n\n"
        "👇 Выберите действие:"
    )


def _inventory_lines(items: list[UserItem]) -> str:
    if not items:
        return "  <i>пусто</i>"
    lines = []
    for it in items:
        p = CATALOG[it.item]
        extra = f" — {ROLE_NAMES[it.role]}" if it.item == ItemType.ACTIVE_ROLE and it.role else ""
        lines.append(f"  {p.emoji} {p.name}{extra} × {it.amount}")
    return "\n".join(lines)


def profile_text(user: User, items: list[UserItem]) -> str:
    s = user.stats
    level = effective_level(user)
    status = f"\n🎖 Статус: <b>{LEVEL_NAMES[level]}</b>" if level else ""
    return (
        f"👤 <b>Профиль</b> — {escape(user.full_name)}\n"
        f"🆔 <code>{user.id}</code>{status}\n\n"
        f"💰 <b>Баланс</b>\n  💵 {user.money}   💎 {user.diamonds}\n\n"
        f"🎒 <b>Инвентарь</b>\n{_inventory_lines(items)}\n\n"
        f"🏆 <b>Статистика</b>\n"
        f"  🎮 Игр: {s.games_played}\n"
        f"  🥇 Побед всего: {s.wins_total}\n"
        f"  🕊 За мирных: {s.wins_peace}\n"
        f"  🤵 За мафию: {s.wins_mafia}\n"
        f"  🔪 За нейтралов: {s.wins_neutral}"
    )


def shop_text(user: User) -> str:
    lines = [f"🛒 <b>Магазин</b>\n\n💵 {user.money}   💎 {user.diamonds}\n"]
    for p in CATALOG.values():
        lines.append(f"{p.emoji} <b>{p.name}</b> — {p.price} {currency_sign(p)}\n<i>{p.desc}</i>\n")
    return "\n".join(lines)


def roles_shop_text(user: User) -> str:
    return (
        "🃏 <b>Активная роль</b> — 1 💎\n"
        "Выберите роль. Если её купили несколько игроков, "
        "она достанется случайному из них.\n\n"
        f"💎 {user.diamonds}"
    )


def admin_panel_text(user: User) -> str:
    return (
        "🛠 <b>Админ-панель</b>\n\n"
        f"Ваш уровень: <b>{LEVEL_NAMES[effective_level(user)]}</b>\n"
        "Доступные действия:"
    )
