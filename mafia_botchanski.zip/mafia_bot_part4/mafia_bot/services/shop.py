from dataclasses import dataclass

from sqlalchemy.ext.asyncio import AsyncSession

from db.models import ItemType, Role, User
from db.repo.users import add_item


@dataclass(frozen=True)
class Product:
    emoji: str
    name: str
    price: int
    currency: str  # "money" 💵 | "diamonds" 💎
    desc: str


CATALOG: dict[ItemType, Product] = {
    ItemType.DOCUMENTS: Product("📁", "Документы", 190, "money", "Комиссар увидит вас как «Мирный житель»"),
    ItemType.SHIELD: Product("🛡", "Защита", 140, "money", "Спасает от убийства 1 раз (кроме Убийцы)"),
    ItemType.MASK: Product("🎭", "Маска", 1, "diamonds", "Скрывает роль от Бомжа и Журналиста"),
    ItemType.RIFLE: Product("🔫", "Винтовка", 1, "diamonds", "Игнорирует обычную защиту"),
    ItemType.KILLER_SHIELD: Product("⛑", "Защита от Убийцы", 2, "diamonds", "Спасает от Убийцы"),
    ItemType.VOTE_SHIELD: Product("⚖️", "Защита от голосования", 1, "diamonds", "Вас нельзя повесить днём"),
    ItemType.ACTIVE_ROLE: Product("🃏", "Активная роль", 1, "diamonds", "Гарантированная нужная роль"),
}

ACTIVE_ROLES_FOR_SALE: list[Role] = [
    Role.COMMISSAR, Role.SERGEANT, Role.DOCTOR, Role.LOVER, Role.HOBO,
    Role.DON, Role.LAWYER, Role.KILLER, Role.JOURNALIST,
    Role.MANIAC, Role.ARSONIST, Role.SWINDLER, Role.SNITCH, Role.MAGE, Role.ALCHEMIST,
]


def currency_sign(p: Product) -> str:
    return "💵" if p.currency == "money" else "💎"


async def buy_item(
    session: AsyncSession, user: User, item: ItemType, role: Role | None = None
) -> tuple[bool, str]:
    p = CATALOG[item]
    if item == ItemType.ACTIVE_ROLE:
        if role not in ACTIVE_ROLES_FOR_SALE:
            return False, "❌ Эта роль недоступна"
    else:
        role = None
    if getattr(user, p.currency) < p.price:
        return False, f"❌ Недостаточно {currency_sign(p)}"
    setattr(user, p.currency, getattr(user, p.currency) - p.price)
    await add_item(session, user.id, item, role)
    await session.commit()
    return True, f"✅ Куплено: {p.emoji} {p.name}"
