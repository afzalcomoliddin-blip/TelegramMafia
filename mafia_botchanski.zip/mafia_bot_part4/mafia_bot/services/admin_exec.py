"""Бизнес-логика админ-действий. Одна точка входа execute() — для команд и для панели."""
import re
from datetime import datetime, timedelta, timezone
from html import escape

from aiogram import Bot
from aiogram.exceptions import TelegramBadRequest, TelegramForbiddenError
from aiogram.types import ChatPermissions
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from config import OWNER_ID
from db.enums import AdminLevel, GamePhase, ItemType, Role, Team
from db.models import AdminLog, BotSettings, ChatSettings, Game, Mute, User, Warn
from db.repo.games import get_active_game, get_chat_settings
from db.repo.users import add_item, find_user
from game.constants import ACTIVE_ROLES
from game.manager import manager
from services.logs import log_action
from services.permissions import effective_level, has_perm
from services.shop import CATALOG
from texts.common import fmt_user
from texts.roles import ROLE_NAMES
from utils import utcnow

NO_RIGHTS = "⛔ Недостаточно прав"
WARN_DAYS, WARN_LIMIT = 7, 3
MAX_MUTE = timedelta(days=30)
OFF = {"off", "0", "нет", "отмена", "cancel"}
_DUR = re.compile(r"^(\d{1,4})([mhd])$", re.I)
_UNITS = {"m": "minutes", "h": "hours", "d": "days"}

USAGE = {
    "timers": "⏱ <b>Таймеры игры в этом чате</b> (секунды)\n<code>/timers &lt;регистрация&gt; &lt;ночь&gt; &lt;день&gt; &lt;голосование&gt;</code>\nПример: <code>/timers 120 60 60 45</code>\nПределы: 30–600 / 30–180 / 15–300 / 15–180. Без аргументов — показать текущие. Работает в группе.",
    "warn": "⚠️ <b>Варн</b> (действует 7 дней, 3 варна = кик + бан)\n<code>/warn &lt;id|@username&gt; &lt;причина&gt;</code>\nили ответом на сообщение: <code>/warn причина</code>",
    "unwarn": "♻️ <b>Снять варн</b>\n<code>/unwarn &lt;id|@username&gt;</code>",
    "mute": "🔇 <b>Мут</b>\n<code>/mute &lt;id|@username&gt; &lt;время&gt; &lt;причина&gt;</code>\nВремя: 1m, 30m, 1h, 1d (до 30d). Можно ответом на сообщение.\nСнять: <code>/unmute &lt;id|@username&gt;</code>",
    "unmute": "<code>/unmute &lt;id|@username&gt;</code>",
    "ban": "⛔ <b>Бан</b>\n<code>/ban &lt;id|@username&gt; [причина]</code>",
    "unban": "✅ <b>Разбан</b>\n<code>/unban &lt;id|@username&gt;</code>",
    "give": "💎 <b>Выдача</b>\n<code>/give &lt;id|@username&gt; money|diamonds &lt;N&gt;</code>\n<code>/give &lt;id|@username&gt; item &lt;предмет&gt; [роль] [N]</code>\nПредметы: documents, shield, mask, rifle, killer_shield, vote_shield, active_role (для неё укажите роль, например doctor).",
}

COMMAND_PERM = {
    "warn": "warn", "unwarn": "unwarn", "mute": "mute", "unmute": "mute", "ban": "ban",
    "unban": "unban", "give": "give", "logs": "logs", "stats": "stats",
    "stopgame": "stop_game", "onlyactive": "onlyactive", "forceactive": "forceactive", "timers": "timers",
}


# ───────── утилиты ─────────
def parse_duration(s: str) -> timedelta | None:
    m = _DUR.match(s)
    if not m:
        return None
    delta = timedelta(**{_UNITS[m.group(2).lower()]: int(m.group(1))})
    return delta if timedelta(0) < delta <= MAX_MUTE else None


def guard(admin: User, target: User) -> str | None:
    if target.id == admin.id:
        return "❌ Нельзя применить к себе."
    if target.id == OWNER_ID or effective_level(target) >= effective_level(admin):
        return "⛔ Нельзя применить к равному или старшему по должности."
    return None


async def notify(bot: Bot, user_id: int, text: str) -> None:
    try:
        await bot.send_message(user_id, text)
    except (TelegramBadRequest, TelegramForbiddenError):
        pass


async def _kick(bot: Bot, chat_id: int, user_id: int) -> bool:
    try:
        await bot.ban_chat_member(chat_id, user_id)
        return True
    except (TelegramBadRequest, TelegramForbiddenError):
        return False


async def active_warns(session: AsyncSession, user_id: int) -> list[Warn]:
    res = await session.execute(
        select(Warn).where(Warn.user_id == user_id, Warn.is_active.is_(True), Warn.expires_at > utcnow())
        .order_by(Warn.id)
    )
    return list(res.scalars())


# ───────── варны / баны / муты ─────────
async def do_warn(bot, session, admin, target, reason, chat_id) -> str:
    if not reason:
        return "❌ Укажите причину варна.\n\n" + USAGE["warn"]
    if err := guard(admin, target):
        return err
    session.add(Warn(user_id=target.id, admin_id=admin.id, reason=reason,
                     expires_at=utcnow() + timedelta(days=WARN_DAYS)))
    await session.flush()
    n = len(await active_warns(session, target.id))
    await log_action(session, admin.id, "warn", target.id, f"{n}/{WARN_LIMIT}: {reason}")
    text = f"⚠️ {fmt_user(target)} получает варн <b>{n}/{WARN_LIMIT}</b>\n📝 {escape(reason)}"
    await notify(bot, target.id, f"⚠️ Вам выдан варн ({n}/{WARN_LIMIT}) на {WARN_DAYS} дней.\n📝 Причина: {escape(reason)}")
    if n >= WARN_LIMIT:
        target.is_banned = True
        target.ban_reason = f"{WARN_LIMIT} варна: {reason}"
        await log_action(session, admin.id, "autoban", target.id, "3 активных варна")
        text += "\n🚫 3 варна — бан в боте"
        if chat_id is not None:
            text += " и кик из группы" if await _kick(bot, chat_id, target.id) else " (кик не удался — нет прав у бота)"
        await notify(bot, target.id, "🚫 Вы получили 3 варна и заблокированы в боте.")
    await session.commit()
    return text


async def do_unwarn(session, admin, target) -> str:
    warns = await active_warns(session, target.id)
    if not warns:
        return f"ℹ️ У {fmt_user(target)} нет активных варнов."
    warns[-1].is_active = False
    await log_action(session, admin.id, "unwarn", target.id)
    await session.commit()
    return f"♻️ Варн снят с {fmt_user(target)}. Осталось: <b>{len(warns) - 1}/{WARN_LIMIT}</b>"


async def do_ban(bot, session, admin, target, reason, chat_id) -> str:
    if err := guard(admin, target):
        return err
    target.is_banned = True
    target.ban_reason = reason or "не указана"
    await log_action(session, admin.id, "ban", target.id, target.ban_reason)
    await session.commit()
    extra = ""
    if chat_id is not None:
        extra = " Кик из группы выполнен." if await _kick(bot, chat_id, target.id) else " Кик из группы не удался."
    await notify(bot, target.id, f"🚫 Вы заблокированы в боте.\n📝 Причина: {escape(target.ban_reason)}")
    return f"⛔ {fmt_user(target)} забанен.\n📝 {escape(target.ban_reason)}{extra}"


async def do_unban(bot, session, admin, target, chat_id) -> str:
    target.is_banned = False
    target.ban_reason = None
    for w in await active_warns(session, target.id):  # чистый лист, иначе следующий варн сразу забанит
        w.is_active = False
    await log_action(session, admin.id, "unban", target.id)
    await session.commit()
    if chat_id is not None:
        try:
            await bot.unban_chat_member(chat_id, target.id, only_if_banned=True)
        except (TelegramBadRequest, TelegramForbiddenError):
            pass
    await notify(bot, target.id, "✅ Вы разблокированы в боте.")
    return f"✅ {fmt_user(target)} разбанен, варны сброшены."


async def do_mute(bot, session, admin, target, delta, reason, chat_id) -> str:
    if not reason:
        return "❌ Укажите причину мута.\n\n" + USAGE["mute"]
    if err := guard(admin, target):
        return err
    until = utcnow() + delta
    target.muted_until = until
    session.add(Mute(user_id=target.id, chat_id=chat_id or 0, admin_id=admin.id, reason=reason, until=until))
    await log_action(session, admin.id, "mute", target.id, f"{delta}: {reason}")
    await session.commit()
    note = ""
    if chat_id is not None:
        try:
            await bot.restrict_chat_member(
                chat_id, target.id, permissions=ChatPermissions(can_send_messages=False),
                until_date=datetime.now(timezone.utc) + delta,
            )
        except (TelegramBadRequest, TelegramForbiddenError):
            note = "\n⚠️ Telegram-ограничение не применено (нет прав у бота) — сообщения будут удаляться."
    await notify(bot, target.id, f"🔇 Вы в муте до {until:%d.%m %H:%M} UTC.\n📝 Причина: {escape(reason)}")
    return f"🔇 {fmt_user(target)} в муте на <b>{delta}</b>.\n📝 {escape(reason)}{note}"


async def do_unmute(bot, session, admin, target, chat_id) -> str:
    target.muted_until = None
    await log_action(session, admin.id, "unmute", target.id)
    await session.commit()
    if chat_id is not None:
        try:
            chat = await bot.get_chat(chat_id)
            await bot.restrict_chat_member(chat_id, target.id, permissions=chat.permissions)
        except (TelegramBadRequest, TelegramForbiddenError):
            pass
    return f"🔊 Мут с {fmt_user(target)} снят."


# ───────── выдача ─────────
async def do_give(bot, session, admin, target, rest) -> str:
    usage = USAGE["give"]
    if not rest:
        return usage
    kind = rest[0].lower()
    if kind in ("money", "деньги", "💵", "diamonds", "алмазы", "💎"):
        field, label = ("money", "💵") if kind in ("money", "деньги", "💵") else ("diamonds", "💎")
        if len(rest) < 2 or not rest[1].isdigit() or not 1 <= int(rest[1]) <= 1_000_000:
            return usage
        amount = int(rest[1])
        setattr(target, field, getattr(target, field) + amount)
        what = f"{amount} {label}"
    elif kind in ("item", "предмет"):
        try:
            item = ItemType(rest[1].lower())
        except (IndexError, ValueError):
            return usage
        role, idx = None, 2
        if item == ItemType.ACTIVE_ROLE:
            try:
                role = Role(rest[2].lower())
            except (IndexError, ValueError):
                return usage
            if role not in ACTIVE_ROLES:
                return "❌ Эта роль не активная.\n\n" + usage
            idx = 3
        amount = int(rest[idx]) if len(rest) > idx and rest[idx].isdigit() else 1
        if not 1 <= amount <= 100:
            return usage
        await add_item(session, target.id, item, role, amount)
        p = CATALOG[item]
        what = f"{p.emoji} {p.name}" + (f" ({ROLE_NAMES[role]})" if role else "") + f" × {amount}"
    else:
        return usage
    await log_action(session, admin.id, "give", target.id, what)
    await session.commit()
    await notify(bot, target.id, f"🎁 Вам выдано: {what}")
    return f"🎁 {fmt_user(target)} получает: {what}"


# ───────── логи / статистика ─────────
async def do_logs(session, n: int = 20) -> str:
    n = max(1, min(n, 30))
    rows = (await session.execute(select(AdminLog).order_by(AdminLog.id.desc()).limit(n))).scalars().all()
    if not rows:
        return "📜 Логов пока нет."
    ids = {r.admin_id for r in rows} | {r.target_id for r in rows if r.target_id}
    users = {u.id: u for u in (await session.execute(select(User).where(User.id.in_(ids)))).scalars()}

    def nm(i: int) -> str:
        u = users.get(i)
        return f"@{escape(u.username)}" if u and u.username else f"<code>{i}</code>"

    lines = ["📜 <b>Логи администрации</b>\n"]
    for r in rows:
        line = f"<code>{r.created_at:%d.%m %H:%M}</code> {nm(r.admin_id)} · <b>{escape(r.action)}</b>"
        if r.target_id:
            line += f" → {nm(r.target_id)}"
        if r.details:
            line += f"\n   <i>{escape(r.details[:120])}</i>"
        lines.append(line)
    return "\n".join(lines)[:4000]


async def do_stats(session) -> str:
    now = utcnow()

    async def cnt(*where, model=User) -> int:
        return (await session.execute(select(func.count()).select_from(model).where(*where))).scalar_one()

    users = await cnt()
    d1 = await cnt(User.created_at >= now - timedelta(days=1))
    d7 = await cnt(User.created_at >= now - timedelta(days=7))
    banned = await cnt(User.is_banned.is_(True))
    muted = await cnt(User.muted_until > now)
    admins = await cnt(User.admin_level != AdminLevel.NONE)
    warns = await cnt(Warn.is_active.is_(True), Warn.expires_at > now, model=Warn)
    chats = await cnt(model=ChatSettings)
    total = await cnt(model=Game)
    running = await cnt(Game.phase != GamePhase.FINISHED, model=Game)
    w = {t: await cnt(Game.winner_team == t, model=Game) for t in Team}
    return (
        "📊 <b>Статистика бота</b>\n\n"
        f"👥 Пользователей: <b>{users}</b> (+{d1} за сутки, +{d7} за неделю)\n"
        f"🚫 Забанено: {banned} · 🔇 В муте: {muted}\n"
        f"⚠️ Активных варнов: {warns} · 🛡 Админов: {admins}\n"
        f"💬 Известных чатов: {chats}\n\n"
        f"🎮 Игр всего: <b>{total}</b> (идёт: {running}, завершено: {total - running})\n"
        f"🏆 Победы: 🕊 {w[Team.PEACE]} · 🤵 {w[Team.MAFIA]} · 🔪 {w[Team.NEUTRAL]}"
    )


# ───────── игровые админ-действия ─────────
async def do_stop_game(bot, session, admin, game: Game) -> str:
    game.phase = GamePhase.FINISHED
    game.finished_at = utcnow()
    await log_action(session, admin.id, "stop_game", None, f"chat {game.chat_id}, game {game.id}")
    await session.commit()
    manager.drop(game.chat_id)
    try:
        await bot.send_message(game.chat_id, "🛑 Игра остановлена администратором.")
    except (TelegramBadRequest, TelegramForbiddenError):
        pass
    return f"🛑 Игра в чате <code>{game.chat_id}</code> остановлена."


async def do_onlyactive(bot, session, admin, game: Game, enable: bool) -> str:
    if game.phase != GamePhase.REGISTRATION:
        return "❌ Роли уже розданы — режим меняется только до старта игры."
    game.only_active = enable
    await log_action(session, admin.id, "onlyactive", None, f"{'on' if enable else 'off'}, chat {game.chat_id}")
    await session.commit()
    try:
        await bot.send_message(game.chat_id, "🎯 Режим «только активные роли» " + ("включён." if enable else "отменён."))
    except (TelegramBadRequest, TelegramForbiddenError):
        pass
    return "🎯 Только активные роли: " + ("<b>вкл</b>" if enable else "<b>выкл</b>")


async def get_force_active(session) -> bool:
    s = await session.get(BotSettings, 1)
    return bool(s and s.force_active)


async def do_forceactive(session, admin, enable: bool) -> str:
    s = await session.get(BotSettings, 1)
    if s is None:
        s = BotSettings(id=1)
        session.add(s)
    s.force_active = enable
    await log_action(session, admin.id, "forceactive", None, "on" if enable else "off")
    await session.commit()
    return "🔥 Новые игры без «Мирных жителей»: " + ("<b>вкл</b>" if enable else "<b>выкл</b>")


# ───────── единая точка входа ─────────
async def execute(cmd: str, *, bot: Bot, session: AsyncSession, admin: User,
                  chat_id: int | None, args: list[str], reply_user: User | None = None) -> str:
    if cmd not in COMMAND_PERM or not has_perm(admin, COMMAND_PERM[cmd]):
        return NO_RIGHTS
    in_group = chat_id is not None and chat_id < 0
    gid = chat_id if in_group else None

    if cmd == "logs":
        return await do_logs(session, int(args[0]) if args and args[0].isdigit() else 20)
    if cmd == "stats":
        return await do_stats(session)
    if cmd == "timers":
        if not in_group:
            return USAGE["timers"]
        cs = await get_chat_settings(session, chat_id)
        if not args:
            return (f"⏱ Сейчас: регистрация {cs.registration_seconds}, ночь {cs.night_seconds}, "
                    f"день {cs.day_seconds}, голосование {cs.vote_seconds} сек.")
        limits = [(30, 600), (30, 180), (15, 300), (15, 180)]
        if len(args) != 4 or not all(a.isdigit() for a in args):
            return USAGE["timers"]
        nums = [int(a) for a in args]
        if any(not lo <= n <= hi for n, (lo, hi) in zip(nums, limits)):
            return "❌ Значение вне допустимых пределов.\n\n" + USAGE["timers"]
        cs.registration_seconds, cs.night_seconds, cs.day_seconds, cs.vote_seconds = nums
        await log_action(session, admin.id, "timers", None, f"chat {chat_id}: {nums}")
        await session.commit()
        return "⏱ Таймеры обновлены (новые игры): регистрация {}, ночь {}, день {}, голосование {} сек.".format(*nums)
    if cmd == "forceactive":
        return await do_forceactive(session, admin, enable=not (args and args[0].lower() in OFF))

    if cmd in ("stopgame", "onlyactive"):
        rest = args
        if in_group:
            target_chat = chat_id
        elif args and args[0].lstrip("-").isdigit():
            target_chat, rest = int(args[0]), args[1:]
        else:
            return f"ℹ️ В личке укажите ID чата: <code>/{cmd} &lt;chat_id&gt;</code> (или откройте админ-панель)."
        game = await get_active_game(session, target_chat)
        if not game:
            return "❌ В этом чате нет активной игры."
        if cmd == "stopgame":
            return await do_stop_game(bot, session, admin, game)
        return await do_onlyactive(bot, session, admin, game, enable=not (rest and rest[0].lower() in OFF))

    # команды с целью-пользователем
    if reply_user is not None:
        target, rest = reply_user, list(args)
    else:
        target = await find_user(session, args[0]) if args else None
        rest = list(args[1:])
    if target is None:
        return "❌ Пользователь не найден (он должен был написать боту).\n\n" + USAGE[cmd]

    if cmd == "warn":
        return await do_warn(bot, session, admin, target, " ".join(rest).strip(), gid)
    if cmd == "unwarn":
        return await do_unwarn(session, admin, target)
    if cmd == "ban":
        return await do_ban(bot, session, admin, target, " ".join(rest).strip(), gid)
    if cmd == "unban":
        return await do_unban(bot, session, admin, target, gid)
    if cmd == "unmute":
        return await do_unmute(bot, session, admin, target, gid)
    if cmd == "mute":
        delta = parse_duration(rest[0]) if rest else None
        if delta is None:
            return "❌ Неверное время.\n\n" + USAGE["mute"]
        return await do_mute(bot, session, admin, target, delta, " ".join(rest[1:]).strip(), gid)
    if cmd == "give":
        return await do_give(bot, session, admin, target, rest)
    return NO_RIGHTS
