import asyncio
import logging

from aiogram import Bot
from aiogram.exceptions import TelegramBadRequest, TelegramForbiddenError, TelegramRetryAfter
from sqlalchemy import select

from db.models import User
from db.session import SessionMaker
from services.logs import log_action

log = logging.getLogger(__name__)
_tasks: set[asyncio.Task] = set()


def start_broadcast(bot: Bot, admin_id: int, from_chat_id: int, message_id: int) -> None:
    task = asyncio.create_task(_run(bot, admin_id, from_chat_id, message_id))
    _tasks.add(task)
    task.add_done_callback(_tasks.discard)


async def _run(bot: Bot, admin_id: int, from_chat_id: int, message_id: int) -> None:
    async with SessionMaker() as session:
        ids = list((await session.execute(select(User.id).where(User.is_banned.is_(False)))).scalars())
    sent = failed = 0
    for uid in ids:
        for attempt in (1, 2):
            try:
                await bot.copy_message(uid, from_chat_id, message_id)
                sent += 1
            except TelegramRetryAfter as e:
                await asyncio.sleep(e.retry_after)
                continue  # одна повторная попытка
            except (TelegramForbiddenError, TelegramBadRequest):
                failed += 1
            break
        else:
            failed += 1
        await asyncio.sleep(0.05)  # ~20 сообщений/с — в пределах лимитов Telegram
    async with SessionMaker() as session:
        await log_action(session, admin_id, "broadcast", None, f"sent={sent}, failed={failed}")
        await session.commit()
    try:
        await bot.send_message(admin_id, f"📢 <b>Рассылка завершена</b>\n✅ Доставлено: {sent}\n❌ Не доставлено: {failed}")
    except (TelegramBadRequest, TelegramForbiddenError):
        log.warning("не удалось отправить отчёт о рассылке")
