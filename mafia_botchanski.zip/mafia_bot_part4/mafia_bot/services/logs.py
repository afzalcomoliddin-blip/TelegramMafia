from sqlalchemy.ext.asyncio import AsyncSession

from db.models import AdminLog


async def log_action(
    session: AsyncSession, admin_id: int, action: str,
    target_id: int | None = None, details: str | None = None,
) -> None:
    session.add(AdminLog(admin_id=admin_id, action=action, target_id=target_id, details=details))
