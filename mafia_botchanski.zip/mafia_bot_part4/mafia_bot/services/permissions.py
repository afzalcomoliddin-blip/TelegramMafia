from db.models import AdminLevel, User
from config import OWNER_ID

LEVEL_NAMES = {
    AdminLevel.NONE: "Игрок",
    AdminLevel.MODERATOR: "🛡 Модератор",
    AdminLevel.JUNIOR: "🔰 Младший администратор",
    AdminLevel.ADMIN: "⚙️ Администратор",
    AdminLevel.SENIOR: "🔱 Старший администратор",
    AdminLevel.COOWNER: "💠 Совладелец",
    AdminLevel.OWNER: "👑 Владелец",
}

# действие -> (минимальный уровень, название кнопки)
ACTIONS: dict[str, tuple[AdminLevel, str]] = {
    "warn": (AdminLevel.ADMIN, "⚠️ Выдать варн"),
    "unwarn": (AdminLevel.ADMIN, "♻️ Снять варн"),
    "mute": (AdminLevel.MODERATOR, "🔇 Мут"),
    "ban": (AdminLevel.SENIOR, "⛔ Бан"),
    "unban": (AdminLevel.SENIOR, "✅ Разбан"),
    "give": (AdminLevel.COOWNER, "💎 Выдать валюту/предметы"),
    "stop_game": (AdminLevel.ADMIN, "🛑 Остановить игру"),
    "onlyactive": (AdminLevel.ADMIN, "🎯 Только активные (/onlyactive)"),
    "forceactive": (AdminLevel.SENIOR, "🔥 Без мирных (/forceactive)"),
    "stats": (AdminLevel.SENIOR, "📊 Статистика бота"),
    "logs": (AdminLevel.COOWNER, "📜 Логи администрации"),
    "broadcast": (AdminLevel.COOWNER, "📢 Рассылка"),
    "timers": (AdminLevel.ADMIN, "⏱ Таймеры игры"),
}


def effective_level(user: User) -> AdminLevel:
    # Владелец определяется по ID, а не по записи в БД
    if user.id == OWNER_ID:
        return AdminLevel.OWNER
    return AdminLevel(user.admin_level)


def has_perm(user: User, action: str) -> bool:
    need = ACTIONS.get(action)
    return bool(need) and effective_level(user) >= need[0]


def available_actions(user: User) -> list[str]:
    return [a for a in ACTIONS if has_perm(user, a)]
