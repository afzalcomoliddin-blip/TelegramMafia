from aiogram import BaseMiddleware
from aiogram.exceptions import TelegramBadRequest, TelegramForbiddenError
from aiogram.types import CallbackQuery, Message

from db.repo.games import get_chat_settings
from db.repo.users import get_or_create_user
from db.session import SessionMaker
from utils import utcnow

GROUPS = {"group", "supergroup"}
_seen_chats: dict[int, str | None] = {}  # чтобы не ходить в БД на каждое сообщение


class UserMiddleware(BaseMiddleware):
    """Регистрирует пользователя и чат, блокирует забаненных, удаляет сообщения замученных."""

    async def __call__(self, handler, event, data):
        tg = data.get("event_from_user")
        if tg is None or tg.is_bot:
            return await handler(event, data)

        async with SessionMaker() as session:
            user = await get_or_create_user(session, tg)

            if user.is_banned:
                if isinstance(event, CallbackQuery):
                    await event.answer("🚫 Вы заблокированы в этом боте", show_alert=True)
                elif isinstance(event, Message) and event.chat.type == "private":
                    await event.answer("🚫 Вы заблокированы в этом боте.")
                return None

            if isinstance(event, Message) and event.chat.type in GROUPS:
                chat = event.chat
                if _seen_chats.get(chat.id, "?") != chat.title:
                    await get_chat_settings(session, chat.id, chat.title)
                    _seen_chats[chat.id] = chat.title
                if user.muted_until and user.muted_until > utcnow():
                    try:
                        await event.delete()
                    except (TelegramBadRequest, TelegramForbiddenError):
                        pass
                    return None

            data["session"] = session
            data["user"] = user
            return await handler(event, data)
