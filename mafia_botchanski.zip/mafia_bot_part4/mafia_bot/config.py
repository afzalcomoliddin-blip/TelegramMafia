import os

from dotenv import load_dotenv

load_dotenv()

# Токен можно вписать сюда или положить в .env (BOT_TOKEN=...)
BOT_TOKEN = os.getenv("BOT_TOKEN", "8998296886:AAHuEymWREYpXCJRC3OaqChvcPLGER8aDcQ")

# Жёстко прописанный владелец бота
OWNER_ID = 1323156997

# PostgreSQL: postgresql+asyncpg://user:pass@localhost:5432/mafia
DATABASE_URL = os.getenv("DATABASE_URL", "sqlite+aiosqlite:///mafia.db")

# Пусто — FSM в памяти. Для продакшена: redis://localhost:6379/0
REDIS_URL = os.getenv("REDIS_URL", "")
