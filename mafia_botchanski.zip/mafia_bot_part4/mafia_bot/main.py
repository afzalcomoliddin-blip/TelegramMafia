import asyncio
import logging

from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.fsm.storage.memory import MemoryStorage

from config import BOT_TOKEN, REDIS_URL
from db.repo.games import close_stale_games
from db.session import SessionMaker, init_db
from handlers import admin, admin_cmds, game, game_actions, game_chat, help as help_h, profile, shop, start
from middlewares.user import UserMiddleware


async def main() -> None:
    logging.basicConfig(level=logging.INFO)
    if BOT_TOKEN == "YOUR_BOT_TOKEN_HERE":
        raise SystemExit("Укажите BOT_TOKEN в .env или в config.py")

    if REDIS_URL:
        from aiogram.fsm.storage.redis import RedisStorage
        storage = RedisStorage.from_url(REDIS_URL)
    else:
        storage = MemoryStorage()

    bot = Bot(BOT_TOKEN, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
    dp = Dispatcher(storage=storage)

    mw = UserMiddleware()
    dp.message.outer_middleware(mw)
    dp.callback_query.outer_middleware(mw)
    # game раньше start: deep-link «/start join_<id>» должен перехватываться первым
    dp.include_routers(
        game.router, game_actions.router, help_h.router, start.router, profile.router,
        shop.router, admin_cmds.router, admin.router, game_chat.router,  # game_chat — всегда последним
    )

    await init_db()
    async with SessionMaker() as session:
        closed = await close_stale_games(session)
    if closed:
        logging.info("Закрыто незавершённых игр после перезапуска: %s", closed)
    await dp.start_polling(bot)


if __name__ == "__main__":
    asyncio.run(main())
