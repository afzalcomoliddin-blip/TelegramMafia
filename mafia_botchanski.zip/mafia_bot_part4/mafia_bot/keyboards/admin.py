from aiogram.types import InlineKeyboardMarkup
from aiogram.utils.keyboard import InlineKeyboardBuilder

_PHASES = {"registration": "набор", "night": "ночь", "day": "день", "voting": "голосование"}


def back_kb() -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    b.button(text="⬅️ Админ панель", callback_data="admin:panel")
    return b.as_markup()


def force_active_kb() -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    b.button(text="✅ Включить", callback_data="admin:fa:on")
    b.button(text="❌ Выключить", callback_data="admin:fa:off")
    b.button(text="⬅️ Админ панель", callback_data="admin:panel")
    b.adjust(2, 1)
    return b.as_markup()


def games_kb(rows, prefix: str) -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    for game, cs in rows:
        name = (cs.title if cs and cs.title else str(game.chat_id))[:24]
        mark = " 🎯" if game.only_active else ""
        b.button(text=f"{name} · {_PHASES.get(game.phase.value, game.phase.value)}{mark}",
                 callback_data=f"{prefix}:{game.id}")
    b.button(text="⬅️ Админ панель", callback_data="admin:panel")
    b.adjust(1)
    return b.as_markup()


def broadcast_confirm_kb() -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    b.button(text="✅ Отправить", callback_data="bc:yes")
    b.button(text="❌ Отмена", callback_data="bc:no")
    return b.as_markup()
