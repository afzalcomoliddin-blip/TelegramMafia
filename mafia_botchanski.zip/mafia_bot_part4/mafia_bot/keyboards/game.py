from aiogram import Bot
from aiogram.types import InlineKeyboardMarkup
from aiogram.utils.keyboard import InlineKeyboardBuilder


async def join_kb(bot: Bot, game_id: int, can_start: bool = False) -> InlineKeyboardMarkup:
    me = await bot.me()
    b = InlineKeyboardBuilder()
    # Переход в ЛС гарантирует, что бот сможет написать роль и кнопки действий
    b.button(text="🕹 Войти в игру", url=f"https://t.me/{me.username}?start=join_{game_id}")
    if can_start:  # появляется при 5+ игроках; нажать могут создатель и админы
        b.button(text="▶️ Начать игру", callback_data=f"gs:{game_id}")
    b.adjust(1)
    return b.as_markup()
