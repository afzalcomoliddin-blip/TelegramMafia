from aiogram.types import InlineKeyboardMarkup
from aiogram.utils.keyboard import InlineKeyboardBuilder


def _sizes(n: int) -> list[int]:
    return [2] * (n // 2) + ([1] if n % 2 else [])


def targets_kb(gid: int, items: list[tuple[int, str]], burn: bool = False) -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    for uid, label in items:
        b.button(text=label[:32], callback_data=f"na:{gid}:t:{uid}")
    sizes = _sizes(len(items))
    if burn:
        b.button(text="🔥 Поджечь всех (и себя)", callback_data=f"na:{gid}:b")
        sizes.append(1)
    if sizes:
        b.adjust(*sizes)
    return b.as_markup()


def commissar_kb(gid: int) -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    b.button(text="🔍 Проверить", callback_data=f"na:{gid}:m:c")
    b.button(text="🔫 Убить", callback_data=f"na:{gid}:m:k")
    b.adjust(2)
    return b.as_markup()


def mage_kb(gid: int, attacker: int) -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    b.button(text="🕊 Помиловать", callback_data=f"mg:{gid}:{attacker}:p")
    b.button(text="💀 Убить", callback_data=f"mg:{gid}:{attacker}:k")
    b.adjust(2)
    return b.as_markup()


def kamikaze_kb(gid: int, items: list[tuple[int, str]]) -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    for uid, label in items:
        b.button(text=label[:32], callback_data=f"kz:{gid}:{uid}")
    b.adjust(*_sizes(len(items)))
    return b.as_markup()


def vote_kb(gid: int, items: list[tuple[int, str]]) -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    for uid, label in items:
        b.button(text=label[:32], callback_data=f"vt:{gid}:{uid}")
    b.button(text="🚫 Пропустить", callback_data=f"vt:{gid}:0")
    b.adjust(*_sizes(len(items)), 1)
    return b.as_markup()


def open_bot_kb(username: str, text: str = "🤖 Перейти в бота") -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    b.button(text=text, url=f"https://t.me/{username}")
    return b.as_markup()
