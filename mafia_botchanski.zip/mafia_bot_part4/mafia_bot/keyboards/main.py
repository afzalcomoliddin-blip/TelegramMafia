from aiogram.types import InlineKeyboardMarkup
from aiogram.utils.keyboard import InlineKeyboardBuilder

from db.models import ItemType, User
from services.permissions import ACTIONS, available_actions, effective_level
from services.shop import ACTIVE_ROLES_FOR_SALE, CATALOG, currency_sign
from texts.roles import ROLE_NAMES


def main_menu() -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    b.button(text="👤 Профиль", callback_data="menu:profile")
    b.button(text="🛒 Магазин", callback_data="menu:shop")
    b.button(text="📖 Помощь", callback_data="menu:help")
    b.button(text="🎮 Создать игру", callback_data="game:create")
    b.button(text="➕ Присоединиться", callback_data="game:join")
    b.adjust(2, 1, 2)
    return b.as_markup()


def profile_kb(user: User) -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    b.button(text="🛒 Магазин", callback_data="menu:shop")
    b.button(text="📖 Помощь", callback_data="menu:help")
    if effective_level(user):
        b.button(text="🛠 Админ панель", callback_data="admin:panel")
    b.button(text="⬅️ Меню", callback_data="menu:main")
    b.adjust(2, 1, 1)
    return b.as_markup()


def shop_kb() -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    for item, p in CATALOG.items():
        cb = "shop:roles" if item == ItemType.ACTIVE_ROLE else f"shop:buy:{item.value}"
        b.button(text=f"{p.emoji} {p.name} · {p.price} {currency_sign(p)}", callback_data=cb)
    b.button(text="👤 Профиль", callback_data="menu:profile")
    b.button(text="⬅️ Меню", callback_data="menu:main")
    b.adjust(1, 1, 1, 1, 1, 1, 1, 2)
    return b.as_markup()


def roles_shop_kb() -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    for r in ACTIVE_ROLES_FOR_SALE:
        b.button(text=ROLE_NAMES[r], callback_data=f"shop:role:{r.value}")
    b.button(text="⬅️ Магазин", callback_data="shop:main")
    b.adjust(*([2] * (len(ACTIVE_ROLES_FOR_SALE) // 2)), 1, 1)
    return b.as_markup()


def admin_panel_kb(user: User) -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    acts = available_actions(user)
    for a in acts:
        b.button(text=ACTIONS[a][1], callback_data=f"admin:act:{a}")
    b.button(text="⬅️ Профиль", callback_data="menu:profile")
    b.adjust(*([1] * len(acts)), 1)
    return b.as_markup()
